import os, time, subprocess, traceback, tempfile, shutil, stat, base64, hashlib, re
from datetime import datetime, date
from pathlib import Path
import boto3

from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy import create_engine, String, Integer, Date, DateTime, ForeignKey, Text, Boolean, text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

DB=os.environ['DATABASE_URL']
ROOT=Path(os.environ.get('GIT_REPO_ROOT','/data/git-repos'))
SECRET_KEY=os.environ['SECRET_KEY']
HOST_KEY_CHECKING=os.environ.get('ANSIBLE_HOST_KEY_CHECKING','false').lower() == 'true'

engine=create_engine(DB,pool_pre_ping=True)
Session=sessionmaker(bind=engine,autoflush=False)

class Base(DeclarativeBase): pass

class AnsibleJob(Base):
    __tablename__='ansible_jobs'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    job_type:Mapped[str]=mapped_column(String(50),default='syntax_check')
    playbook_id:Mapped[int|None]=mapped_column(Integer,nullable=True)
    server_id:Mapped[int|None]=mapped_column(Integer,nullable=True)
    status:Mapped[str]=mapped_column(String(30),default='Queued')
    requested_by:Mapped[str]=mapped_column(String(100))
    logs:Mapped[str|None]=mapped_column(Text,nullable=True)
    exit_code:Mapped[int|None]=mapped_column(Integer,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    started_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
    finished_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)

class Playbook(Base):
    __tablename__='ansible_playbooks'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    repository_id:Mapped[int]=mapped_column(Integer)
    name:Mapped[str]=mapped_column(String(255))
    path:Mapped[str]=mapped_column(String(1000))
    last_commit:Mapped[str|None]=mapped_column(String(100),nullable=True)
    last_synced:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)

class Server(Base):
    __tablename__='servers'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    hostname:Mapped[str]=mapped_column(String(255))
    ip_address:Mapped[str]=mapped_column(String(64))
    instance_id:Mapped[str|None]=mapped_column(String(100),nullable=True)
    os:Mapped[str|None]=mapped_column(String(100),nullable=True)
    os_version:Mapped[str|None]=mapped_column(String(100),nullable=True)
    environment:Mapped[str|None]=mapped_column(String(100),nullable=True)
    application:Mapped[str|None]=mapped_column(String(255),nullable=True)
    owner:Mapped[str|None]=mapped_column(String(255),nullable=True)
    aws_account:Mapped[str|None]=mapped_column(String(255),nullable=True)
    aws_account_id:Mapped[str|None]=mapped_column(String(30),nullable=True)
    aws_region:Mapped[str|None]=mapped_column(String(50),nullable=True)
    aws_group_tag:Mapped[str|None]=mapped_column(String(255),nullable=True)
    ssh_credential_id:Mapped[int|None]=mapped_column(Integer,nullable=True)
    next_patch_date:Mapped[date|None]=mapped_column(Date,nullable=True)
    status:Mapped[str]=mapped_column(String(30),default='Running')

class AWSAccount(Base):
    __tablename__='aws_accounts'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    name:Mapped[str]=mapped_column(String(255))
    account_id:Mapped[str]=mapped_column(String(30),unique=True,index=True)
    role_arn:Mapped[str|None]=mapped_column(String(255),nullable=True)
    regions:Mapped[str]=mapped_column(Text,default='eu-west-1')
    group_tag_key:Mapped[str]=mapped_column(String(100),default='PatchGroup')
    enabled:Mapped[bool]=mapped_column(Boolean,default=True)

class SSHCredential(Base):
    __tablename__='ssh_credentials'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    name:Mapped[str]=mapped_column(String(255))
    username:Mapped[str]=mapped_column(String(100))
    private_key_encrypted:Mapped[str]=mapped_column(Text)
    passphrase_encrypted:Mapped[str|None]=mapped_column(Text,nullable=True)
    patch_group:Mapped[str|None]=mapped_column(String(255),nullable=True)
    enabled:Mapped[bool]=mapped_column(Boolean,default=True)

class Patch(Base):
    __tablename__='patch_history'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    server_id:Mapped[int]=mapped_column(Integer)
    patch_date:Mapped[date]=mapped_column(Date)
    patch_type:Mapped[str|None]=mapped_column(String(100),nullable=True)
    os_version:Mapped[str|None]=mapped_column(String(100),nullable=True)
    kernel_version:Mapped[str|None]=mapped_column(String(255),nullable=True)
    performed_by:Mapped[str|None]=mapped_column(String(255),nullable=True)
    source:Mapped[str|None]=mapped_column(String(50),nullable=True)
    result:Mapped[str|None]=mapped_column(String(50),default='Success')
    reboot_required:Mapped[bool]=mapped_column(Boolean,default=False)
    reboot_completed:Mapped[bool]=mapped_column(Boolean,default=False)
    aap_job_id:Mapped[str|None]=mapped_column(String(100),nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow,nullable=False)
    comments:Mapped[str|None]=mapped_column(Text,nullable=True)

class AMIBackup(Base):
    __tablename__='ami_backups'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    server_id:Mapped[int]=mapped_column(Integer)
    ami_id:Mapped[str|None]=mapped_column(String(100),nullable=True)
    ami_name:Mapped[str|None]=mapped_column(String(255),nullable=True)
    status:Mapped[str]=mapped_column(String(30),default='Creating')
    region:Mapped[str|None]=mapped_column(String(50),nullable=True)
    aws_account_id:Mapped[str|None]=mapped_column(String(30),nullable=True)
    no_reboot:Mapped[bool]=mapped_column(Boolean,default=True)
    requested_by:Mapped[str]=mapped_column(String(100))
    error_message:Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    completed_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)

def ensure_worker_schema():
    Base.metadata.create_all(engine)

def encryption_key():
    return base64.urlsafe_b64encode(hashlib.sha256(SECRET_KEY.encode()).digest())

fernet=Fernet(encryption_key())

def decrypt_secret(value):
    if not value:
        return ''
    try:
        return fernet.decrypt(value.encode()).decode()
    except InvalidToken:
        raise RuntimeError('Stored SSH credential cannot be decrypted. Check SECRET_KEY.')

def set_log(db,job,text):
    job.logs=(job.logs or '') + text
    job.logs=job.logs[-100000:]
    db.commit()

def effective_credential(db, server):
    c=None
    if server.ssh_credential_id:
        c=db.get(SSHCredential,server.ssh_credential_id)
        if c and c.enabled:
            return c
    if server.aws_group_tag:
        for candidate in db.query(SSHCredential).filter(SSHCredential.enabled==True).order_by(SSHCredential.id.asc()).all():
            if candidate.patch_group and candidate.patch_group.lower()==server.aws_group_tag.lower():
                return candidate
    return None

def aws_session_for(account):
    region=os.environ.get('AWS_REGION','eu-west-1')
    if account.role_arn:
        sts=boto3.client('sts',region_name=region)
        c=sts.assume_role(
            RoleArn=account.role_arn,
            RoleSessionName=f'patch-portal-job-{account.id}'
        )['Credentials']
        return boto3.Session(
            aws_access_key_id=c['AccessKeyId'],
            aws_secret_access_key=c['SecretAccessKey'],
            aws_session_token=c['SessionToken'],
            region_name=region
        )
    return boto3.Session(region_name=region)

def update_patch_date_tag(db,server,patch_date):
    if not server.instance_id:
        return False,'Server has no EC2 Instance ID.'
    if not server.aws_account_id:
        return False,'Server has no AWS Account ID.'
    if not server.aws_region:
        return False,'Server has no AWS Region.'

    account=db.query(AWSAccount).filter(
        AWSAccount.account_id==server.aws_account_id
    ).first()
    if not account:
        return False,f'AWS account {server.aws_account_id} is not configured in the portal.'
    if not account.enabled:
        return False,f'AWS account {server.aws_account_id} is disabled.'

    try:
        session=aws_session_for(account)
        actual=session.client('sts').get_caller_identity()['Account']
        if actual != server.aws_account_id:
            return False,f'AWS role resolved to account {actual}, expected {server.aws_account_id}.'
        ec2=session.client('ec2',region_name=server.aws_region)
        ec2.create_tags(
            Resources=[server.instance_id],
            Tags=[{'Key':'PatchDate','Value':patch_date.isoformat()}]
        )
        return True,f'PatchDate={patch_date.isoformat()} applied to {server.instance_id}.'
    except Exception as exc:
        return False,f'PatchDate tag update failed: {exc}'


def run_patch_after_backup(job_id):
    db=Session()
    job=db.get(AnsibleJob,job_id)
    if not job:
        db.close(); return
    try:
        job.status='Running'
        job.started_at=datetime.utcnow()
        job.logs=(job.logs or '')+'AMI backup gate: waiting for the requested backup to become Available...\n'
        db.commit()
        server=db.get(Server,job.server_id) if job.server_id else None
        if not server: raise RuntimeError('Server not found.')
        # The one-click route writes the exact AMI ID into the job log.
        m=re.search(r'Backup:\s*(ami-[A-Za-z0-9]+)',job.logs or '')
        if not m: raise RuntimeError('One-click job is missing its requested AMI ID.')
        ami_id=m.group(1)
        backup=db.query(AMIBackup).filter(AMIBackup.server_id==server.id,AMIBackup.ami_id==ami_id).first()
        if not backup: raise RuntimeError(f'AMI backup record {ami_id} was not found.')
        # Wait up to 30 minutes for AWS AMI availability. poll_ami_backup normally
        # updates the same record, so this job observes its status.
        for _ in range(180):
            db.expire_all()
            backup=db.get(AMIBackup,backup.id)
            if backup.status=='Available':
                set_log(db,job,f'AMI BACKUP: {ami_id} is Available. Starting Ansible patch.\n')
                db.close()
                run_patch(job_id)
                return
            if backup.status=='Failed':
                raise RuntimeError(f'AMI backup {ami_id} failed: {backup.error_message or "AWS reported failure."}')
            time.sleep(10)
        raise RuntimeError(f'AMI backup {ami_id} did not become Available within 30 minutes.')
    except Exception as e:
        try: db.rollback()
        except Exception: pass
        job=db.get(AnsibleJob,job_id)
        if job:
            job.status='Failed'; job.exit_code=1; job.finished_at=datetime.utcnow()
            job.logs=(job.logs or '')+'\nONE-CLICK PATCH FAILED: '+str(e)+'\n'+traceback.format_exc()
            job.logs=job.logs[-100000:]; db.commit()
    finally:
        db.close()

def run_patch(job_id):
    db=Session()
    job=db.get(AnsibleJob,job_id)
    server=db.get(Server,job.server_id) if job.server_id else None
    play=db.get(Playbook,job.playbook_id) if job.playbook_id else None
    tempdir=None
    agent_proc=None
    try:
        job.status='Running'
        job.started_at=datetime.utcnow()
        job.logs='Ansible patch job started.\n'
        db.commit()

        if not server: raise RuntimeError('Server not found.')
        if not play: raise RuntimeError('Playbook not found.')
        if server.status == 'Terminated': raise RuntimeError('Server is Terminated.')
        cred=effective_credential(db,server)
        if not cred: raise RuntimeError('No enabled SSH credential is mapped to this server or its PatchGroup.')

        repo=ROOT/str(play.repository_id)
        play_path=(repo/play.path).resolve()
        repo_path=repo.resolve()
        if not play_path.exists(): raise RuntimeError(f'Playbook file not found: {play_path}')
        if repo_path not in play_path.parents: raise RuntimeError('Invalid playbook path.')

        key=decrypt_secret(cred.private_key_encrypted)
        passphrase=decrypt_secret(cred.passphrase_encrypted) if cred.passphrase_encrypted else ''
        tempdir=Path(tempfile.mkdtemp(prefix=f'patchportal-job-{job.id}-'))
        key_path=tempdir/'id_key'

        # Normalize keys copied from browsers/Windows/CSV forms before OpenSSH reads them.
        # This handles CRLF, UTF-8 BOM and literal "\\n" sequences without changing valid key material.
        key=key.lstrip('\ufeff').replace('\r\n','\n').replace('\r','\n').strip()
        if '\\\\n' in key and '\n' not in key:
            key=key.replace('\\\\n','\n')
        key += '\n'
        key_path.write_text(key,encoding='utf-8',newline='\n')
        os.chmod(key_path,0o600)

        # Validate the key before Ansible starts. This turns the opaque libcrypto error
        # into a useful job error and proves that the decrypted key is usable by OpenSSH.
        key_check=subprocess.run(
            ['ssh-keygen','-y','-f',str(key_path)],
            input=(passphrase+'\n') if passphrase else None,
            capture_output=True,text=True,timeout=15
        )
        if key_check.returncode != 0:
            stderr=(key_check.stderr or key_check.stdout or 'ssh-keygen rejected the private key').strip()
            raise RuntimeError(f'SSH private key validation failed: {stderr}')

        inventory=tempdir/'inventory.ini'
        inventory.write_text(
            '[patch_target]\n'
            f'{server.hostname} ansible_host={server.ip_address} ansible_user={cred.username} '
            'ansible_python_interpreter=auto_silent\n'
        )
        os.chmod(inventory,0o600)

        env=os.environ.copy()
        env['ANSIBLE_HOST_KEY_CHECKING']='True' if HOST_KEY_CHECKING else 'False'
        env['ANSIBLE_NOCOLOR']='1'
        env['ANSIBLE_RETRY_FILES_ENABLED']='False'
        env['ANSIBLE_LOCALHOST_WARNING']='False'

        # If the key is passphrase-protected, load it into a temporary ssh-agent.
        if passphrase:
            agent=subprocess.run(['ssh-agent','-s'],capture_output=True,text=True,check=True)
            for line in agent.stdout.splitlines():
                if line.startswith('SSH_AUTH_SOCK='):
                    env['SSH_AUTH_SOCK']=line.split(';',1)[0].split('=',1)[1]
                elif line.startswith('SSH_AGENT_PID='):
                    env['SSH_AGENT_PID']=line.split(';',1)[0].split('=',1)[1]
            askpass=tempdir/'askpass.sh'
            askpass.write_text('#!/bin/sh\nprintf "%s\\n" "$SSH_KEY_PASSPHRASE"\n')
            os.chmod(askpass,0o700)
            env['SSH_ASKPASS']=str(askpass)
            env['SSH_KEY_PASSPHRASE']=passphrase
            env['DISPLAY']='patchportal:0'
            subprocess.run(['ssh-add',str(key_path)],env=env,check=True,capture_output=True,text=True)

        # Pre-flight SSH connection test. Do not run the playbook unless SSH works.
        ssh_cmd=['ssh','-i',str(key_path),'-o','BatchMode=yes','-o','ConnectTimeout=10']
        if not HOST_KEY_CHECKING:
            ssh_cmd += ['-o','StrictHostKeyChecking=no','-o','UserKnownHostsFile=/dev/null']
        ssh_cmd += [f'{cred.username}@{server.ip_address}','true']
        ssh_env=env.copy()
        ssh_test=subprocess.run(ssh_cmd,env=ssh_env,capture_output=True,text=True,timeout=20)
        if ssh_test.returncode != 0:
            detail=(ssh_test.stderr or ssh_test.stdout or 'SSH connection failed').strip()
            raise RuntimeError(f'SSH pre-flight failed for {cred.username}@{server.ip_address}: {detail}')
        set_log(db,job,'SSH private key validation: PASS\nSSH pre-flight connection: PASS\n')

        set_log(db,job,f'Server: {server.hostname} ({server.ip_address})\n')
        set_log(db,job,f'Playbook: {play.name} ({play.path})\n')
        set_log(db,job,f'SSH credential: {cred.name} / {cred.username}\n')
        set_log(db,job,'Starting ansible-playbook...\n\n')

        proc=subprocess.Popen(
            ['ansible-playbook','-i',str(inventory),str(play_path),'--private-key',str(key_path)],
            cwd=str(repo),
            stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,env=env
        )
        for line in proc.stdout:
            # Never expose credential material.
            safe=line.replace(passphrase,'[REDACTED]') if passphrase else line
            set_log(db,job,safe)
        rc=proc.wait()
        job.exit_code=rc
        job.finished_at=datetime.utcnow()
        job.status='Success' if rc==0 else 'Failed'
        db.commit()

        if rc==0:
            output=(job.logs or '').lower()
            reboot_required=(
                bool(re.search(r'\breboot\s+is\s+required\b', output)) or
                bool(re.search(r'\breboot\s+required\b', output)) or
                bool(re.search(r'\breboot_required\s*[:=]\s*true\b', output))
            )
            patch_date=date.today()

            # Patch history is the authoritative record and is committed first.
            patch=Patch(
                server_id=server.id,
                patch_date=patch_date,
                patch_type='Ansible Patching',
                os_version=server.os_version,
                performed_by=job.requested_by,
                source='Ansible',
                result='Success',
                reboot_required=reboot_required,
                reboot_completed=False,
                aap_job_id=f'ANSIBLE-{job.id}',
                created_at=datetime.utcnow(),
                comments=f'Playbook: {play.name}; Git commit: {play.last_commit or "-"}; Backup: {(re.search(r"Required backup: ([^\\n]+)", job.logs or "") or [None, "-"])[1]}; Ansible Job #{job.id}'
            )
            db.add(patch)
            db.add(AuditLog(username=job.requested_by,action='PATCH_EXECUTION_COMPLETED',server_id=server.id,
                            details=f'Ansible Job #{job.id}; playbook={play.name}; result=Success; reboot_required={reboot_required}; patch_date={patch_date}'))
            db.commit()

            # AWS tag update is deliberately independent. A tag failure must never
            # remove the successful patch history record.
            tag_ok,tag_msg=update_patch_date_tag(db,server,patch_date)
            if tag_ok:
                set_log(db,job,f'\nPATCH RESULT: SUCCESS\nPatch history record created automatically.\nAWS TAG: {tag_msg}\n')
            else:
                set_log(db,job,f'\nPATCH RESULT: SUCCESS\nPatch history record created automatically.\nAWS TAG WARNING: {tag_msg}\n')

            if reboot_required:
                set_log(db,job,'REBOOT REQUIRED: YES\nUse Reboot Server on the server page after reviewing the patch result.\n')
            else:
                set_log(db,job,'REBOOT REQUIRED: NO\n')
        else:
            set_log(db,job,'\nPATCH RESULT: FAILED\nNo successful patch history record was created.\n')
    except Exception as e:
        try:
            db.rollback()
        except Exception:
            pass
        job=db.get(AnsibleJob,job_id)
        if job:
            job.status='Failed'
            job.exit_code=1
            job.finished_at=datetime.utcnow()
            job.logs=(job.logs or '')+'\nERROR: '+str(e)+'\n'+traceback.format_exc()
            job.logs=job.logs[-100000:]
            db.add(AuditLog(username=job.requested_by if job else 'system',action='ANSIBLE_JOB_FAILED',server_id=job.server_id if job else None,
                            details=f'Job #{job_id} ({job.job_type if job else "unknown"}) failed: {str(e)[:1000]}'))
            db.commit()
    finally:
        try:
            if env.get('SSH_AGENT_PID') and env.get('SSH_AUTH_SOCK'):
                subprocess.run(['ssh-agent','-k'],env=env,capture_output=True,text=True)
        except Exception:
            pass
        if tempdir:
            shutil.rmtree(tempdir,ignore_errors=True)
        db.close()

def run_reboot(job_id):
    db=Session()
    job=db.get(AnsibleJob,job_id)
    server=db.get(Server,job.server_id) if job and job.server_id else None
    tempdir=None
    env=os.environ.copy()
    try:
        job.status='Running'
        job.started_at=datetime.utcnow()
        job.logs='Reboot job started.\n'
        db.commit()

        if not server: raise RuntimeError('Server not found.')
        if server.status=='Terminated': raise RuntimeError('Server is Terminated.')
        cred=effective_credential(db,server)
        if not cred: raise RuntimeError('No enabled SSH credential is mapped to this server or its PatchGroup.')

        key=decrypt_secret(cred.private_key_encrypted)
        passphrase=decrypt_secret(cred.passphrase_encrypted) if cred.passphrase_encrypted else ''
        tempdir=Path(tempfile.mkdtemp(prefix=f'patchportal-reboot-{job.id}-'))
        key_path=tempdir/'id_key'
        # Normalize exactly as the working patch path does. The previous reboot
        # implementation wrote a literal backslash+n (`\\n`) into the key,
        # which causes OpenSSH/libcrypto to reject otherwise valid keys.
        key=key.lstrip('\ufeff').replace('\r\n','\n').replace('\r','\n').strip()
        if '\\\\n' in key and '\n' not in key:
            key=key.replace('\\\\n','\n')
        key+='\n'
        key_path.write_text(key,encoding='utf-8',newline='\n')
        os.chmod(key_path,0o600)
        os.chmod(key_path,0o600)

        kc=subprocess.run(['ssh-keygen','-y','-f',str(key_path)],
                          input=(passphrase+'\n') if passphrase else None,
                          capture_output=True,text=True,timeout=15)
        if kc.returncode!=0:
            raise RuntimeError(f'SSH private key validation failed: {(kc.stderr or kc.stdout).strip()}')

        inventory=tempdir/'inventory.ini'
        inventory.write_text('[patch_target]\n'+
            f'{server.hostname} ansible_host={server.ip_address} ansible_user={cred.username} ansible_python_interpreter=auto_silent\n')
        os.chmod(inventory,0o600)

        # Prefer an approved Git restart/reboot playbook selected when the job was queued.
        # Fall back to the portal's built-in single-server reboot workflow if none exists.
        reboot_play=None
        if job.playbook_id:
            p=db.get(Playbook,job.playbook_id)
            if p:
                repo=ROOT/str(p.repository_id)
                candidate=repo/p.path
                if candidate.exists():
                    reboot_play=candidate
                    set_log(db,job,f'Using Git reboot playbook: {p.name} ({p.path})\n')
        if reboot_play is None:
            reboot_play=tempdir/'reboot.yml'
            reboot_play.write_text('''- name: Reboot Linux server
  hosts: all
  become: true
  gather_facts: false
  tasks:
    - name: Reboot the server
      ansible.builtin.reboot:
        reboot_timeout: 900
        connect_timeout: 10
        pre_reboot_delay: 5
        post_reboot_delay: 30
        test_command: whoami
    - name: Verify server is reachable after reboot
      ansible.builtin.ping:
''')

        env['ANSIBLE_HOST_KEY_CHECKING']='True' if HOST_KEY_CHECKING else 'False'
        env['ANSIBLE_NOCOLOR']='1'
        env['ANSIBLE_RETRY_FILES_ENABLED']='False'
        env['ANSIBLE_LOCALHOST_WARNING']='False'

        # Support encrypted private keys for reboot exactly like patch jobs.
        if passphrase:
            agent=subprocess.run(['ssh-agent','-s'],capture_output=True,text=True,check=True)
            for line in agent.stdout.splitlines():
                if line.startswith('SSH_AUTH_SOCK='):
                    env['SSH_AUTH_SOCK']=line.split(';',1)[0].split('=',1)[1]
                elif line.startswith('SSH_AGENT_PID='):
                    env['SSH_AGENT_PID']=line.split(';',1)[0].split('=',1)[1]
            askpass=tempdir/'askpass.sh'
            askpass.write_text('#!/bin/sh\nprintf "%s\\n" "$SSH_KEY_PASSPHRASE"\n')
            os.chmod(askpass,0o700)
            env['SSH_ASKPASS']=str(askpass)
            env['SSH_KEY_PASSPHRASE']=passphrase
            env['DISPLAY']='patchportal:0'
            subprocess.run(['ssh-add',str(key_path)],env=env,check=True,capture_output=True,text=True)

        ssh_cmd=['ssh','-i',str(key_path),'-o','BatchMode=yes','-o','ConnectTimeout=10']
        if not HOST_KEY_CHECKING:
            ssh_cmd += ['-o','StrictHostKeyChecking=no','-o','UserKnownHostsFile=/dev/null']
        ssh_cmd += [f'{cred.username}@{server.ip_address}','true']
        tst=subprocess.run(ssh_cmd,env=env,capture_output=True,text=True,timeout=20)
        if tst.returncode!=0:
            raise RuntimeError(f'SSH pre-flight failed: {(tst.stderr or tst.stdout).strip()}')
        set_log(db,job,'SSH private key validation: PASS\nSSH pre-flight connection: PASS\nStarting controlled reboot...\n\n')

        proc=subprocess.Popen(['ansible-playbook','-i',str(inventory),str(reboot_play),'--private-key',str(key_path)],
                              cwd=str(tempdir),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,env=env)
        for line in proc.stdout:
            set_log(db,job,line)
        rc=proc.wait()
        job.exit_code=rc
        job.finished_at=datetime.utcnow()
        job.status='Success' if rc==0 else 'Failed'
        db.commit()

        if rc==0:
            db.add(AuditLog(username=job.requested_by,action='REBOOT_EXECUTION_COMPLETED',server_id=server.id,
                            details=f'Ansible Job #{job.id}; reboot workflow completed successfully.'))
            patch=db.query(Patch).filter(
                Patch.server_id==server.id,
                Patch.result=='Success',
                Patch.reboot_required==True,
                Patch.reboot_completed==False
            ).order_by(Patch.patch_date.desc(),Patch.id.desc()).first()
            if patch:
                patch.reboot_completed=True
                patch.comments=(patch.comments or '')+' Reboot completed successfully via Patch Portal.'
                db.commit()
            set_log(db,job,'\nREBOOT RESULT: SUCCESS\nServer rebooted and post-reboot connectivity check passed.\n')
        else:
            set_log(db,job,'\nREBOOT RESULT: FAILED\nThe server reboot workflow did not complete successfully.\n')
    except Exception as e:
        try: db.rollback()
        except Exception: pass
        job=db.get(AnsibleJob,job_id)
        if job:
            job.status='Failed'
            job.exit_code=1
            job.finished_at=datetime.utcnow()
            job.logs=(job.logs or '')+'\\nERROR: '+str(e)+'\\n'+traceback.format_exc()
            job.logs=job.logs[-100000:]
            db.commit()
    finally:
        if tempdir: shutil.rmtree(tempdir,ignore_errors=True)
        db.close()

def run_syntax(job_id):
    db=Session(); job=db.get(AnsibleJob,job_id); p=db.get(Playbook,job.playbook_id) if job.playbook_id else None
    try:
        job.status='Running'; job.started_at=datetime.utcnow(); job.logs='Worker started.\n'; db.commit()
        if not p: raise RuntimeError('Playbook not found.')
        repo=ROOT/str(p.repository_id); play=repo/p.path
        if not play.exists(): raise RuntimeError(f'Playbook file not found: {play}')
        proc=subprocess.Popen(['ansible-playbook','--syntax-check',str(play)],cwd=str(repo),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
        lines=[]
        for line in proc.stdout:
            lines.append(line); job.logs=''.join(lines)[-50000:]; db.commit()
        rc=proc.wait(); job.exit_code=rc; job.finished_at=datetime.utcnow(); job.status='Success' if rc==0 else 'Failed'; db.commit()
    except Exception as e:
        job.logs=(job.logs or '')+'ERROR: '+str(e)+'\n'+traceback.format_exc(); job.exit_code=1; job.finished_at=datetime.utcnow(); job.status='Failed'; db.commit()
    finally: db.close()

def run(job_id):
    db=Session()
    job=db.get(AnsibleJob,job_id)
    if not job:
        db.close()
        print(f'Job {job_id} no longer exists',flush=True)
        return
    job_type=job.job_type
    db.close()
    # Each runner loads its own fresh ORM object/session.
    if job_type=='patch':
        run_patch(job_id)
    elif job_type=='patch_after_backup':
        run_patch_after_backup(job_id)
    elif job_type=='reboot':
        run_reboot(job_id)
    elif job_type=='syntax_check':
        run_syntax(job_id)
    else:
        db=Session()
        job=db.get(AnsibleJob,job_id)
        job.status='Failed'
        job.exit_code=1
        job.finished_at=datetime.utcnow()
        job.logs=(job.logs or '')+f'Unsupported job type: {job_type}\n'
        db.commit()
        db.close()

WORKER_VERSION=os.environ.get('APP_VERSION','15.0')
WORKER_BUILD=os.environ.get('APP_BUILD','20260814-05')

def main():
    print('================================================',flush=True)
    print(f'Patch Portal Ansible Worker | Version: {WORKER_VERSION} | Build: {WORKER_BUILD}',flush=True)
    print('================================================',flush=True)
    ensure_worker_schema()
    # Verify the table used by the worker is the same table used by the portal.
    with engine.connect() as conn:
        conn.execute(text('SELECT 1 FROM patch_history LIMIT 1'))
        cols=conn.execute(text("""
            SELECT column_name FROM information_schema.columns
            WHERE table_name='patch_history' AND column_name='created_at'
        """)).fetchall()
        if not cols:
            raise RuntimeError('patch_history.created_at column is missing')
    print('Worker database schema check: PASS (patch_history + created_at)',flush=True)
    while True:
        db=Session()
        job=db.query(AnsibleJob).filter(AnsibleJob.status=='Queued').order_by(AnsibleJob.id).first()
        if job:
            job_id=job.id
            db.commit()
            db.close()
            run(job_id)
        else:
            db.close(); time.sleep(2)

if __name__=='__main__': main()
