import csv, io, os, secrets, json, subprocess, tempfile, shutil, hashlib, base64, time, re, threading
from pathlib import Path
from datetime import datetime, timedelta, date
from typing import Optional

import boto3
import requests
from botocore.exceptions import BotoCoreError, ClientError
from cryptography.fernet import Fernet, InvalidToken
from fastapi import FastAPI, Request, Form, UploadFile, File, HTTPException, Depends
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from passlib.context import CryptContext
from sqlalchemy import create_engine, String, Integer, Date, DateTime, ForeignKey, Text, Boolean, func, or_, Float, Index
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker

DATABASE_URL=os.environ['DATABASE_URL']; SECRET_KEY=os.environ['SECRET_KEY']
ADMIN_USERNAME=os.environ.get('ADMIN_USERNAME','admin'); ADMIN_PASSWORD=os.environ.get('ADMIN_PASSWORD','ChangeMeNow!123')
SESSION_DAYS=int(os.environ.get('SESSION_DAYS','1'))
AWS_REGION=os.environ.get('AWS_REGION','eu-west-1')
AWS_GROUP_TAG_KEY=os.environ.get('AWS_GROUP_TAG_KEY','PatchGroup')
AAP_URL=os.environ.get('AAP_URL','').rstrip('/')
AAP_TOKEN=os.environ.get('AAP_TOKEN','')
AAP_TEMPLATE_ID=os.environ.get('AAP_TEMPLATE_ID','')
AAP_VERIFY_SSL=os.environ.get('AAP_VERIFY_SSL','true').lower()=='true'
PORTAL_API_TOKEN=os.environ.get('PORTAL_API_TOKEN','')
GIT_REPO_ROOT=os.environ.get('GIT_REPO_ROOT','/data/git-repos')

engine=create_engine(DATABASE_URL,pool_pre_ping=True)
SessionLocal=sessionmaker(bind=engine,autoflush=False,autocommit=False)
pwd=CryptContext(schemes=['bcrypt'],deprecated='auto')
serializer=URLSafeTimedSerializer(SECRET_KEY)
app=FastAPI(title='Server Patch Portal',version='10.2')
templates=Jinja2Templates(directory='templates')

class Base(DeclarativeBase): pass
class User(Base):
    __tablename__='users'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    username:Mapped[str]=mapped_column(String(100),unique=True,index=True)
    password_hash:Mapped[str]=mapped_column(String(255))
    role:Mapped[str]=mapped_column(String(30),default='readonly')
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
class Server(Base):
    __tablename__='servers'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    hostname:Mapped[str]=mapped_column(String(255),index=True)
    ip_address:Mapped[str]=mapped_column(String(64),index=True)
    instance_id:Mapped[str|None]=mapped_column(String(100),nullable=True,index=True)
    os:Mapped[str|None]=mapped_column(String(100))
    os_version:Mapped[str|None]=mapped_column(String(100))
    environment:Mapped[str|None]=mapped_column(String(100))
    application:Mapped[str|None]=mapped_column(String(255))
    owner:Mapped[str|None]=mapped_column(String(255))
    aws_account:Mapped[str|None]=mapped_column(String(255))
    aws_account_id:Mapped[str|None]=mapped_column(String(30))
    aws_region:Mapped[str|None]=mapped_column(String(50))
    aws_group_tag:Mapped[str|None]=mapped_column(String(255))
    ssh_credential_id:Mapped[int|None]=mapped_column(Integer,nullable=True,index=True)
    next_patch_date:Mapped[date|None]=mapped_column(Date,nullable=True)
    status:Mapped[str]=mapped_column(String(30),default='Running')
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    updated_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)
    patches=relationship('Patch',back_populates='server',cascade='all, delete-orphan')
    cves=relationship('CVE',back_populates='server',cascade='all, delete-orphan')
class Patch(Base):
    __tablename__='patch_history'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    server_id:Mapped[int]=mapped_column(ForeignKey('servers.id'),index=True)
    patch_date:Mapped[date]=mapped_column(Date)
    patch_type:Mapped[str|None]=mapped_column(String(100))
    os_version:Mapped[str|None]=mapped_column(String(100))
    kernel_version:Mapped[str|None]=mapped_column(String(255))
    performed_by:Mapped[str|None]=mapped_column(String(255))
    source:Mapped[str|None]=mapped_column(String(100))
    result:Mapped[str|None]=mapped_column(String(30),default='Success')
    reboot_required:Mapped[bool]=mapped_column(Boolean,default=False)
    reboot_completed:Mapped[bool]=mapped_column(Boolean,default=False)
    aap_job_id:Mapped[str|None]=mapped_column(String(100))
    comments:Mapped[str|None]=mapped_column(Text)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    server=relationship('Server',back_populates='patches')
class CVE(Base):
    __tablename__='cves'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    server_id:Mapped[int]=mapped_column(ForeignKey('servers.id'),index=True)
    cve_id:Mapped[str]=mapped_column(String(50),index=True)
    severity:Mapped[str]=mapped_column(String(20),default='Medium')
    package:Mapped[str|None]=mapped_column(String(255))
    current_version:Mapped[str|None]=mapped_column(String(255))
    fixed_version:Mapped[str|None]=mapped_column(String(255))
    status:Mapped[str]=mapped_column(String(30),default='Open')
    detected_date:Mapped[date|None]=mapped_column(Date)
    remediated_date:Mapped[date|None]=mapped_column(Date)
    source:Mapped[str|None]=mapped_column(String(100))
    notes:Mapped[str|None]=mapped_column(Text)
    server=relationship('Server',back_populates='cves')
class AAPJob(Base):
    __tablename__='aap_jobs'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    server_id:Mapped[int]=mapped_column(ForeignKey('servers.id'),index=True)
    job_id:Mapped[str]=mapped_column(String(100),index=True)
    status:Mapped[str]=mapped_column(String(30),default='Launched')
    launched_by:Mapped[str]=mapped_column(String(100))
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
class AWSAccount(Base):
    __tablename__='aws_accounts'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    name:Mapped[str]=mapped_column(String(255))
    account_id:Mapped[str]=mapped_column(String(30),unique=True,index=True)
    role_arn:Mapped[str|None]=mapped_column(String(255),nullable=True)
    regions:Mapped[str]=mapped_column(Text,default='eu-west-1')
    group_tag_key:Mapped[str]=mapped_column(String(100),default='PatchGroup')
    enabled:Mapped[bool]=mapped_column(Boolean,default=True)
    last_sync:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
    sync_status:Mapped[str]=mapped_column(String(30),default='Not Synced')
    sync_message:Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    updated_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)

class GitRepository(Base):
    __tablename__='git_repositories'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    name:Mapped[str]=mapped_column(String(255),unique=True,index=True)
    url:Mapped[str]=mapped_column(String(1000))
    branch:Mapped[str]=mapped_column(String(255),default='main')
    username:Mapped[str]=mapped_column(String(255),default='git')
    token_encrypted:Mapped[str]=mapped_column(Text)
    provider:Mapped[str]=mapped_column(String(50),default='github')
    enabled:Mapped[bool]=mapped_column(Boolean,default=True)
    last_sync:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
    last_commit:Mapped[str|None]=mapped_column(String(100),nullable=True)
    sync_status:Mapped[str]=mapped_column(String(30),default='Not Synced')
    sync_message:Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    updated_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)

class SSHCredential(Base):
    __tablename__='ssh_credentials'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    name:Mapped[str]=mapped_column(String(255),unique=True,index=True)
    username:Mapped[str]=mapped_column(String(100),default='svc-ansible')
    private_key_encrypted:Mapped[str]=mapped_column(Text)
    passphrase_encrypted:Mapped[str|None]=mapped_column(Text,nullable=True)
    patch_group:Mapped[str|None]=mapped_column(String(255),nullable=True,index=True)
    enabled:Mapped[bool]=mapped_column(Boolean,default=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    updated_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)

class Playbook(Base):
    __tablename__='ansible_playbooks'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    repository_id:Mapped[int]=mapped_column(ForeignKey('git_repositories.id',ondelete='CASCADE'),index=True)
    name:Mapped[str]=mapped_column(String(255))
    path:Mapped[str]=mapped_column(String(1000))
    last_commit:Mapped[str|None]=mapped_column(String(100),nullable=True)
    last_synced:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class AnsibleJob(Base):
    __tablename__='ansible_jobs'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    job_type:Mapped[str]=mapped_column(String(50),default='syntax_check')
    playbook_id:Mapped[int|None]=mapped_column(ForeignKey('ansible_playbooks.id',ondelete='SET NULL'),nullable=True,index=True)
    server_id:Mapped[int|None]=mapped_column(ForeignKey('servers.id',ondelete='SET NULL'),nullable=True,index=True)
    status:Mapped[str]=mapped_column(String(30),default='Queued',index=True)
    requested_by:Mapped[str]=mapped_column(String(100))
    logs:Mapped[str|None]=mapped_column(Text,nullable=True)
    exit_code:Mapped[int|None]=mapped_column(Integer,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    started_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
    finished_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)

class AMIBackup(Base):
    __tablename__='ami_backups'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    server_id:Mapped[int]=mapped_column(ForeignKey('servers.id',ondelete='CASCADE'),index=True)
    ami_id:Mapped[str|None]=mapped_column(String(100),nullable=True,index=True)
    ami_name:Mapped[str|None]=mapped_column(String(255),nullable=True)
    status:Mapped[str]=mapped_column(String(30),default='Creating',index=True)
    region:Mapped[str|None]=mapped_column(String(50),nullable=True)
    aws_account_id:Mapped[str|None]=mapped_column(String(30),nullable=True,index=True)
    no_reboot:Mapped[bool]=mapped_column(Boolean,default=True)
    requested_by:Mapped[str]=mapped_column(String(100))
    error_message:Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    completed_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)

class AuditLog(Base):
    __tablename__='audit_log'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    username:Mapped[str]=mapped_column(String(100))
    action:Mapped[str]=mapped_column(String(100))
    server_id:Mapped[int|None]=mapped_column(Integer,nullable=True)
    details:Mapped[str|None]=mapped_column(Text)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

def encryption_key():
    # Stable key derived from SECRET_KEY so no Git PAT key is stored separately.
    return base64.urlsafe_b64encode(hashlib.sha256(SECRET_KEY.encode()).digest())

fernet=Fernet(encryption_key())

def encrypt_secret(value):
    return fernet.encrypt(value.encode()).decode()

def decrypt_secret(value):
    try:
        return fernet.decrypt(value.encode()).decode()
    except InvalidToken:
        raise HTTPException(500,'Stored Git credential cannot be decrypted; check SECRET_KEY.')

def validate_git_url(url):
    u=clean(url)
    if not (u.startswith('https://') or u.startswith('http://')):
        raise HTTPException(400,'For PAT authentication, use an HTTPS Git repository URL.')
    if '@' in u.split('://',1)[1].split('/',1)[0]:
        raise HTTPException(400,'Do not put username or PAT credentials inside the Git URL.')
    return u

def git_env(username, token):
    fd,path=tempfile.mkstemp(prefix='git-askpass-',text=True)
    os.close(fd)
    Path(path).write_text('#!/bin/sh\ncase "$1" in\n  *Username*) printf \'%s\\n\' "$GIT_USERNAME";;\n  *) printf \'%s\\n\' "$GIT_TOKEN";;\nesac\n')
    os.chmod(path,0o700)
    env=os.environ.copy()
    env.update({'GIT_ASKPASS':path,'GIT_USERNAME':username or 'git','GIT_TOKEN':token,'GIT_TERMINAL_PROMPT':'0'})
    return env,path

def run_git(args, cwd=None, username='', token='', timeout=180):
    env,path=git_env(username,token)
    try:
        p=subprocess.run(['git',*args],cwd=cwd,env=env,text=True,capture_output=True,timeout=timeout)
        output=(p.stdout or '') + (p.stderr or '')
        if p.returncode != 0:
            # Avoid returning any token if Git ever echoes a credential-bearing URL.
            output=output.replace(token,'[REDACTED]')
            raise RuntimeError(output.strip()[-4000:] or f'git exited with code {p.returncode}')
        return p.stdout.strip()
    finally:
        try: os.remove(path)
        except OSError: pass

def git_test_connection(url, branch, username, token):
    validate_git_url(url)
    out=run_git(['ls-remote','--heads',url,f'refs/heads/{branch}'],username=username,token=token,timeout=60)
    if not out:
        # A valid repository can have no matching branch; surface that clearly.
        raise RuntimeError(f'Git repository is reachable, but branch "{branch}" was not found.')
    return out.split()[0]

def sync_git_repository(db, repo:GitRepository):
    url=validate_git_url(repo.url)
    token=decrypt_secret(repo.token_encrypted)
    root=Path(GIT_REPO_ROOT)
    root.mkdir(parents=True,exist_ok=True)
    repo_dir=root/str(repo.id)
    if (repo_dir/'.git').exists():
        run_git(['fetch','--prune','origin'],cwd=str(repo_dir),username=repo.username,token=token)
        run_git(['checkout','-B',repo.branch,f'origin/{repo.branch}'],cwd=str(repo_dir),username=repo.username,token=token)
        run_git(['reset','--hard',f'origin/{repo.branch}'],cwd=str(repo_dir),username=repo.username,token=token)
    else:
        if repo_dir.exists(): shutil.rmtree(repo_dir)
        run_git(['clone','--branch',repo.branch,'--single-branch',url,str(repo_dir)],username=repo.username,token=token)
    commit=run_git(['rev-parse','HEAD'],cwd=str(repo_dir),username=repo.username,token=token)[:40]
    discovered=[]
    for base,dirs,files in os.walk(repo_dir):
        dirs[:]=[d for d in dirs if d!='.git']
        for fn in files:
            if fn.lower().endswith(('.yml','.yaml')):
                full=Path(base)/fn
                rel=str(full.relative_to(repo_dir))
                discovered.append((fn,rel))
    existing={p.path:p for p in db.query(Playbook).filter_by(repository_id=repo.id).all()}
    now=datetime.utcnow()
    for name,path in discovered:
        p=existing.pop(path,None)
        if not p:
            p=Playbook(repository_id=repo.id,name=name,path=path)
            db.add(p)
        p.name=name;p.last_commit=commit;p.last_synced=now
    for p in existing.values(): db.delete(p)
    repo.last_sync=now;repo.last_commit=commit;repo.sync_status='Success';repo.sync_message=f'Discovered {len(discovered)} YAML playbooks.'
    db.commit()
    return len(discovered),commit

def encrypt_optional_secret(value):
    if value is None or value == '':
        return None
    return encrypt_secret(value)

def decrypt_optional_secret(value):
    if not value:
        return ''
    return decrypt_secret(value)

def validate_private_key_text(private_key):
    key = (private_key or '').strip()
    if not key:
        raise ValueError('Private key is empty.')
    markers = (
        '-----BEGIN OPENSSH PRIVATE KEY-----',
        '-----BEGIN RSA PRIVATE KEY-----',
        '-----BEGIN EC PRIVATE KEY-----',
        '-----BEGIN DSA PRIVATE KEY-----',
        '-----BEGIN PRIVATE KEY-----',
    )
    if not any(m in key for m in markers):
        raise ValueError('The uploaded file does not look like a supported PEM/OpenSSH private key.')
    return key + '\n'

def credential_for_server(db, server):
    # Explicit server mapping wins; otherwise inherit from PatchGroup.
    if server.ssh_credential_id:
        c = db.get(SSHCredential, server.ssh_credential_id)
        if c and c.enabled:
            return c
    if server.aws_group_tag:
        return db.query(SSHCredential).filter(
            SSHCredential.enabled == True,
            func.lower(SSHCredential.patch_group) == func.lower(server.aws_group_tag)
        ).order_by(SSHCredential.id.asc()).first()
    return None

def clean(x): return (x or '').strip()

def migrate_db():
    stmts=[
      "ALTER TABLE servers ADD COLUMN IF NOT EXISTS aws_account_id VARCHAR(30)",
      "ALTER TABLE servers ADD COLUMN IF NOT EXISTS aws_region VARCHAR(50)",
      "ALTER TABLE patch_history ADD COLUMN IF NOT EXISTS result VARCHAR(30) DEFAULT 'Success'",
      "ALTER TABLE patch_history ADD COLUMN IF NOT EXISTS reboot_required BOOLEAN DEFAULT FALSE",
      "ALTER TABLE patch_history ADD COLUMN IF NOT EXISTS reboot_completed BOOLEAN DEFAULT FALSE",
      "ALTER TABLE patch_history ADD COLUMN IF NOT EXISTS aap_job_id VARCHAR(100)",
      "ALTER TABLE servers DROP CONSTRAINT IF EXISTS servers_hostname_key",
      "ALTER TABLE servers DROP CONSTRAINT IF EXISTS servers_ip_address_key",
      "ALTER TABLE servers DROP CONSTRAINT IF EXISTS servers_instance_id_key",
      "CREATE INDEX IF NOT EXISTS ix_servers_aws_account_id ON servers (aws_account_id)",
      "CREATE INDEX IF NOT EXISTS ix_servers_aws_region ON servers (aws_region)",
      "UPDATE aws_accounts SET group_tag_key = 'PatchGroup' WHERE group_tag_key IS NULL OR group_tag_key = '' OR group_tag_key = 'Group'",
      "ALTER TABLE servers ADD COLUMN IF NOT EXISTS ssh_credential_id INTEGER",
      "CREATE INDEX IF NOT EXISTS ix_servers_ssh_credential_id ON servers (ssh_credential_id)",
      "CREATE INDEX IF NOT EXISTS ix_ami_backups_server_id ON ami_backups (server_id)",
      "CREATE INDEX IF NOT EXISTS ix_ami_backups_ami_id ON ami_backups (ami_id)"

    ]
    with engine.begin() as c:
        for stmt in stmts:
            try: c.exec_driver_sql(stmt)
            except Exception: pass

def init_db():
    Base.metadata.create_all(engine); migrate_db(); db=SessionLocal()
    try:
        x=db.query(User).filter_by(username=ADMIN_USERNAME).first()
        if not x: db.add(User(username=ADMIN_USERNAME,password_hash=pwd.hash(ADMIN_PASSWORD),role='main_admin')); db.commit()
        elif x.role!='main_admin': x.role='main_admin'; db.commit()
    finally: db.close()

def current_user(request):
    t=request.cookies.get('session')
    if not t:return None
    try:return serializer.loads(t,max_age=SESSION_DAYS*86400)
    except (BadSignature,SignatureExpired):return None

def require_user(request):
    u=current_user(request); return u if u else RedirectResponse('/login',303)
def require_admin(request):
    u=require_user(request)
    if isinstance(u,RedirectResponse):return u
    if u.get('role') not in ('admin','main_admin'):raise HTTPException(403,'Administrator access required')
    return u
def require_role(request,*roles):
    u=require_user(request)
    if isinstance(u,RedirectResponse):
        return u
    if u.get('role') not in roles:
        raise HTTPException(403,'Insufficient permissions')
    return u

def require_main_admin(request):
    u=require_user(request)
    if isinstance(u,RedirectResponse):return u
    if u.get('role')!='main_admin':raise HTTPException(403,'Main administrator access required')
    return u

def api_authorized(request:Request):
    if not PORTAL_API_TOKEN: raise HTTPException(503,'API token is not configured')
    auth=request.headers.get('Authorization','')
    if not auth.startswith('Bearer '): raise HTTPException(401,'Bearer token required')
    if not secrets.compare_digest(auth[7:],PORTAL_API_TOKEN): raise HTTPException(401,'Invalid API token')

def status_normalize(v):
    v=clean(v)
    m={'running':'Running','stopped':'Stopped','terminated':'Terminated','pending':'Pending','stopping':'Stopping','shutting-down':'Shutting Down'}
    return m.get(v.lower(),v if v else 'Running')

def aws_session_for(account:AWSAccount):
    if account.role_arn:
        sts=boto3.client('sts',region_name=AWS_REGION)
        assumed=sts.assume_role(RoleArn=account.role_arn,RoleSessionName=f'patch-portal-{account.id}')['Credentials']
        return boto3.Session(
            aws_access_key_id=assumed['AccessKeyId'],
            aws_secret_access_key=assumed['SecretAccessKey'],
            aws_session_token=assumed['SessionToken'],
            region_name=AWS_REGION
        )
    return boto3.Session(region_name=AWS_REGION)

def get_account_identity(session):
    sts=session.client('sts')
    account_id=sts.get_caller_identity()['Account']
    account_name=account_id
    try:
        aliases=session.client('iam').list_account_aliases().get('AccountAliases',[])
        if aliases: account_name=aliases[0]
    except Exception: pass
    return account_id,account_name

def parse_patch_date_tag(value):
    value=clean(value)
    if not value:
        return None
    formats=['%Y-%m-%d','%Y/%m/%d','%d/%m/%Y','%d-%m-%Y','%d-%b-%Y','%d-%b-%y','%d %b %Y','%Y-%m-%dT%H:%M:%S','%Y-%m-%dT%H:%M:%SZ']
    for fmt in formats:
        try:
            return datetime.strptime(value,fmt).date()
        except ValueError:
            pass
    try:
        return date.fromisoformat(value[:10])
    except ValueError:
        return None

def ensure_local_aws_account(db):
    session=boto3.Session(region_name=AWS_REGION)
    aid,aname=get_account_identity(session)
    a=db.query(AWSAccount).filter_by(account_id=aid).first()
    if not a:
        a=AWSAccount(name=aname,account_id=aid,role_arn=None,regions=AWS_REGION,group_tag_key=AWS_GROUP_TAG_KEY)
        db.add(a); db.commit(); db.refresh(a)
    return a

def sync_all_accounts_inventory(db, include_local=True):
    if include_local:
        local=ensure_local_aws_account(db)
    else:
        local=None
    accounts=db.query(AWSAccount).filter(AWSAccount.enabled==True).order_by(AWSAccount.name).all()
    results=[]
    for a in accounts:
        try:
            seen,added,updated,patch_imported,patch_skipped=sync_aws_account(db,a)
            db.add(AuditLog(username='system',action='AWS_ACCOUNT_SYNC',details=f'account={a.account_id}, seen={seen}, added={added}, updated={updated}, patch_imported={patch_imported}'))
            db.commit()
            results.append({'account':a.name,'account_id':a.account_id,'seen':seen,'added':added,'updated':updated,'patch_imported':patch_imported,'patch_skipped':patch_skipped,'error':None})
        except Exception as e:
            db.rollback()
            a=db.get(AWSAccount,a.id)
            if a:
                a.sync_status='Failed'; a.sync_message=str(e); db.commit()
            results.append({'account':a.name if a else 'Unknown','account_id':a.account_id if a else '','seen':0,'added':0,'updated':0,'patch_imported':0,'patch_skipped':0,'error':str(e)})
    return results

def sync_aws_account(db, account:AWSAccount, region_list=None):
    session=aws_session_for(account)
    account_id,account_name=get_account_identity(session)
    regions=region_list or [r.strip() for r in (account.regions or '').split(',') if r.strip()] or [AWS_REGION]
    seen=added=updated=patch_imported=patch_skipped=0
    for region in regions:
        ec2=session.client('ec2',region_name=region)
        paginator=ec2.get_paginator('describe_instances')
        for page in paginator.paginate():
            for res in page.get('Reservations',[]):
                for i in res.get('Instances',[]):
                    iid=i.get('InstanceId')
                    if not iid: continue
                    seen+=1
                    tags={x.get('Key'):x.get('Value','') for x in i.get('Tags',[]) if x.get('Key')}
                    h=tags.get('Name') or i.get('PrivateDnsName') or iid
                    ip=i.get('PrivateIpAddress') or ''
                    if not ip: continue
                    s=db.query(Server).filter(Server.aws_account_id==account_id,Server.aws_region==region,Server.instance_id==iid).first()
                    if not s:
                        s=db.query(Server).filter(Server.aws_account_id==account_id,Server.aws_region==region,Server.hostname==h).first()
                    if not s:
                        s=db.query(Server).filter(Server.aws_account_id==account_id,Server.aws_region==region,Server.ip_address==ip).first()
                    is_new=s is None
                    if is_new:
                        s=Server(); added+=1
                    else: updated+=1

                    current_next=s.next_patch_date.isoformat() if s.next_patch_date else ''
                    fields(s,h,ip,iid,i.get('PlatformDetails') or i.get('Platform') or '',s.os_version,tags.get('Environment',''),tags.get('Application',''),tags.get('Owner',''),account_name,account_id,region,tags.get('PatchGroup',''),current_next,status_normalize(i.get('State',{}).get('Name','')))
                    db.add(s)
                    db.flush()

                    patch_tag=tags.get('PatchDate','')
                    if patch_tag:
                        patch_date=parse_patch_date_tag(patch_tag)
                        if patch_date:
                            existing=db.query(Patch).filter(Patch.server_id==s.id,Patch.patch_date==patch_date).first()
                            if not existing:
                                db.add(Patch(server_id=s.id,patch_date=patch_date,patch_type='AWS PatchDate Tag',source='AWS Tag',result='Success',performed_by='AWS',comments=f'Imported from EC2 tag PatchDate={patch_tag}'))
                                patch_imported+=1
                        else:
                            patch_skipped+=1
    account.last_sync=datetime.utcnow(); account.sync_status='Success'; account.sync_message=f'Synced {seen} instances; added {added}, updated {updated}, PatchDate imported {patch_imported}' + (f', invalid PatchDate skipped {patch_skipped}' if patch_skipped else '')
    return seen,added,updated,patch_imported,patch_skipped


def aws_account_for_server(db, server):
    if not server.aws_account_id:
        raise HTTPException(400,'This server is not associated with an AWS account.')
    account=db.query(AWSAccount).filter(AWSAccount.account_id==server.aws_account_id).first()
    if not account:
        raise HTTPException(400,f'AWS account {server.aws_account_id} is not configured in the portal.')
    if not account.enabled:
        raise HTTPException(400,f'AWS account {account.account_id} is disabled.')
    return account

def create_ami_backup_for_server(db, server, requested_by):
    if not server.instance_id:
        raise HTTPException(400,'This server does not have an EC2 Instance ID.')
    account=aws_account_for_server(db,server)
    if not server.aws_region:
        raise HTTPException(400,'This server does not have an AWS Region.')
    session=aws_session_for(account)
    actual_id,_=get_account_identity(session)
    if actual_id != server.aws_account_id:
        raise HTTPException(502,f'AWS role connected to {actual_id}, expected {server.aws_account_id}.')
    ec2=session.client('ec2',region_name=server.aws_region)
    # Tag value requested by the user. ImageName itself includes a UTC suffix to avoid AWS name collisions.
    tag_name=f'{server.hostname}-AMI-Patching-Portal'
    image_name=f'{tag_name}-{datetime.utcnow().strftime("%Y%m%d-%H%M%S")}'
    try:
        response=ec2.create_image(
            InstanceId=server.instance_id,
            Name=image_name,
            Description=f'Patch Portal backup for {server.hostname} ({server.instance_id})',
            NoReboot=True,
            TagSpecifications=[{
                'ResourceType':'image',
                'Tags':[
                    {'Key':'Name','Value':tag_name},
                    {'Key':'PatchPortalServer','Value':server.hostname},
                    {'Key':'PatchPortalServerId','Value':str(server.id)},
                    {'Key':'PatchPortalBackup','Value':'true'}
                ]
            }]
        )
    except (BotoCoreError,ClientError) as e:
        raise HTTPException(502,f'AMI creation failed: {e}')
    ami_id=response.get('ImageId')
    if not ami_id:
        raise HTTPException(502,'AWS did not return an AMI ID.')
    backup=AMIBackup(
        server_id=server.id,ami_id=ami_id,ami_name=image_name,status='Creating',
        region=server.aws_region,aws_account_id=server.aws_account_id,
        no_reboot=True,requested_by=requested_by
    )
    db.add(backup)
    db.add(AuditLog(username=requested_by,action='AMI_BACKUP_STARTED',server_id=server.id,
                    details=f'AMI={ami_id}; tag Name={tag_name}; no_reboot=true; account={server.aws_account_id}; region={server.aws_region}'))
    db.commit()
    db.refresh(backup)
    return backup, account.role_arn

def poll_ami_backup(backup_id):
    db=SessionLocal()
    try:
        backup=db.get(AMIBackup,backup_id)
        if not backup: return
        account=db.query(AWSAccount).filter(AWSAccount.account_id==backup.aws_account_id).first()
        if not account:
            backup.status='Failed'; backup.error_message='AWS account configuration was removed.'; backup.completed_at=datetime.utcnow(); db.commit(); return
        session=aws_session_for(account)
        ec2=session.client('ec2',region_name=backup.region)
        for _ in range(120):  # up to ~20 minutes
            try:
                images=ec2.describe_images(ImageIds=[backup.ami_id])['Images']
                if not images:
                    time.sleep(10); continue
                state=images[0].get('State','unknown')
                if state=='available':
                    # Re-apply the requested Name tag in case it was changed by policy.
                    server=db.get(Server, backup.server_id)
                    tag_name=f'{server.hostname}-AMI-Patching-Portal' if server else backup.ami_name
                    try:
                        ec2.create_tags(Resources=[backup.ami_id],Tags=[{'Key':'Name','Value':tag_name}])
                    except Exception:
                        pass
                    backup.status='Available'; backup.completed_at=datetime.utcnow()
                    db.add(AuditLog(username=backup.requested_by,action='AMI_BACKUP_COMPLETED',server_id=backup.server_id,
                                    details=f'AMI={backup.ami_id}; status=available; no_reboot=true; tag Name={tag_name}'))
                    db.commit(); return
                if state=='failed':
                    backup.status='Failed'; backup.error_message=images[0].get('StateReason') or 'AWS reported AMI creation failure'; backup.completed_at=datetime.utcnow()
                    db.add(AuditLog(username=backup.requested_by,action='AMI_BACKUP_FAILED',server_id=backup.server_id,details=f'AMI={backup.ami_id}; error={backup.error_message}'))
                    db.commit(); return
            except Exception as e:
                # Keep polling transient AWS errors, but record the last one if the timeout is reached.
                last_error=str(e)
            time.sleep(10)
        backup.status='Timeout'; backup.error_message='AMI did not reach available state within 20 minutes.'; backup.completed_at=datetime.utcnow()
        db.add(AuditLog(username=backup.requested_by,action='AMI_BACKUP_TIMEOUT',server_id=backup.server_id,details=f'AMI={backup.ami_id}'))
        db.commit()
    finally:
        db.close()

def fields(s,hostname,ip,instance,osn,osv,env,appn,owner,acct,acctid,region,group,nextd,status):
    s.hostname=clean(hostname); s.ip_address=clean(ip); s.instance_id=clean(instance) or None
    s.os=clean(osn); s.os_version=clean(osv); s.environment=clean(env); s.application=clean(appn); s.owner=clean(owner)
    s.aws_account=clean(acct); s.aws_account_id=clean(acctid); s.aws_region=clean(region); s.aws_group_tag=clean(group)
    s.next_patch_date=date.fromisoformat(nextd) if nextd else None; s.status=status_normalize(status)

PORTAL_VERSION=os.environ.get('APP_VERSION','15.1')

@app.get('/version')
def portal_version():
    return {'application':'Patch Portal','version':PORTAL_VERSION}

@app.on_event('startup')
def startup(): init_db()

@app.get('/login',response_class=HTMLResponse)
def login_page(request:Request): return RedirectResponse('/',303) if current_user(request) else templates.TemplateResponse('login.html',{'request':request,'error':None})
@app.post('/login',response_class=HTMLResponse)
def login(request:Request,username:str=Form(...),password:str=Form(...)):
    db=SessionLocal()
    try:
        u=db.query(User).filter_by(username=clean(username)).first()
        if not u or not pwd.verify(password,u.password_hash): return templates.TemplateResponse('login.html',{'request':request,'error':'Invalid username or password'})
        r=RedirectResponse('/',303); r.set_cookie('session',serializer.dumps({'id':u.id,'username':u.username,'role':u.role}),httponly=True,samesite='lax',max_age=SESSION_DAYS*86400,secure=False); return r
    finally: db.close()
@app.get('/logout')
def logout(): r=RedirectResponse('/login',303);r.delete_cookie('session');return r

def cleanup_stale_jobs(db, max_age_minutes=120):
    cutoff=datetime.utcnow()-timedelta(minutes=max_age_minutes)
    stale=db.query(AnsibleJob).filter(
        AnsibleJob.status.in_(['Queued','Claimed','Running']),
        AnsibleJob.created_at < cutoff
    ).all()
    for job in stale:
        job.status='Timed Out'
        job.finished_at=datetime.utcnow()
        job.exit_code=124
        db.add(AuditLog(username=job.requested_by,action='JOB_TIMEOUT',server_id=job.server_id,
                        details=f'Job #{job.id} ({job.job_type}) automatically marked Timed Out after {max_age_minutes} minutes.'))
    if stale: db.commit()
    return stale

BACKUP_GATE_HOURS=2

def backup_gate_is_valid(backup):
    if not backup or backup.status!='Available' or not backup.no_reboot or not backup.completed_at:
        return False
    return (datetime.utcnow()-backup.completed_at) <= timedelta(hours=BACKUP_GATE_HOURS)

def classify_os(value):
    v=(value or '').lower()
    if 'windows' in v or 'microsoft' in v: return 'Windows'
    if any(x in v for x in ('red hat','rhel','redhat','enterprise linux')): return 'RHEL'
    if 'amazon linux' in v: return 'Amazon Linux'
    if 'ubuntu' in v: return 'Ubuntu'
    if 'suse' in v or 'sles' in v: return 'SUSE'
    if 'oracle linux' in v: return 'Oracle Linux'
    if 'debian' in v: return 'Debian'
    if not v: return 'Unknown'
    return 'Other'

@app.get('/',response_class=HTMLResponse)
def dashboard(request:Request):
    u=require_user(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal();today=date.today()
    try:
        cleanup_stale_jobs(db)
        all_servers=db.query(Server).all(); total=len(all_servers)
        running=sum(s.status=='Running' for s in all_servers); stopped=sum(s.status=='Stopped' for s in all_servers); terminated=sum(s.status=='Terminated' for s in all_servers)
        never=[];over30=[];over60=[];over90=[];next_overdue=[];next_7=[]
        latest_by_server={s.id:db.query(func.max(Patch.patch_date)).filter(Patch.server_id==s.id).scalar() for s in all_servers}
        for s in all_servers:
            latest=latest_by_server[s.id]; days=(today-latest).days if latest else None
            if latest is None:never.append(s)
            elif days>30:over30.append(s)
            if latest and days>60:over60.append(s)
            if latest and days>90:over90.append(s)
            if s.next_patch_date:
                if s.next_patch_date<today:next_overdue.append(s)
                elif s.next_patch_date<=today+timedelta(days=7):next_7.append(s)
        compliant=total-len(never)-len(over30); compliance=round(compliant/total*100,1) if total else 0
        cves=db.query(CVE).filter(CVE.status=='Open').all(); crit=sum(x.severity=='Critical' for x in cves); high=sum(x.severity=='High' for x in cves)
        os_counts={}
        for s in all_servers:
            key=classify_os(s.os)
            os_counts[key]=os_counts.get(key,0)+1
        os_breakdown=sorted(os_counts.items(),key=lambda x:(-x[1],x[0]))
        return templates.TemplateResponse('dashboard.html',{'request':request,'user':u,'total':total,'running':running,'stopped':stopped,'terminated':terminated,'compliance':compliance,'month':db.query(Patch).filter(Patch.patch_date>=today.replace(day=1)).count(),'never':len(never),'over30':len(over30),'over60':len(over60),'over90':len(over90),'next_overdue':len(next_overdue),'next_7':len(next_7),'no_instance':sum(not s.instance_id for s in all_servers),'no_account':sum(not s.aws_account for s in all_servers),'no_group':sum(not s.aws_group_tag for s in all_servers),'open_cves':len(cves),'critical_cves':crit,'high_cves':high,'attention':[(s,latest_by_server[s.id]) for s in (never+over30)[:100]],'os_breakdown':os_breakdown})
    finally:db.close()


@app.get('/patching',response_class=HTMLResponse)
def patching_page(request:Request,q:str='',os_group:str=''):
    u=require_role(request,'main_admin','admin')
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        servers=db.query(Server).order_by(Server.hostname.asc()).all()
        if q:
            t=q.lower()
            servers=[s for s in servers if any(t in (str(v or '').lower()) for v in
                [s.hostname,s.ip_address,s.instance_id,s.aws_group_tag,s.aws_account,s.aws_account_id,s.environment,s.application,s.os])]
        if os_group:
            servers=[s for s in servers if classify_os(s.os)==os_group]
        playbooks=db.query(Playbook).order_by(Playbook.name.asc()).all()
        active={j.server_id for j in db.query(AnsibleJob).filter(AnsibleJob.status.in_(['Queued','Claimed','Running'])).all() if j.server_id}
        return templates.TemplateResponse('patching.html',{
            'request':request,'user':u,'servers':servers,'playbooks':playbooks,
            'active_server_ids':active,'q':q,'os_group':os_group,'classify_os':classify_os
        })
    finally:
        db.close()

@app.post('/patching/submit')
def patching_submit(request:Request,server_ids:str=Form(''),playbook_id:int=Form(...)):
    u=require_role(request,'main_admin','admin')
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        cleanup_stale_jobs(db)
        ids=[]
        for raw in (server_ids or '').split(','):
            try:
                n=int(raw.strip())
                if n not in ids: ids.append(n)
            except ValueError:
                pass
        if not ids:
            raise HTTPException(400,'Select at least one server.')
        play=db.get(Playbook,playbook_id)
        if not play:
            raise HTTPException(400,'Selected playbook was not found.')
        repo=Path(os.environ.get('GIT_REPO_ROOT','/data/git-repos'))/str(play.repository_id)
        play_path=(repo/play.path).resolve()
        if repo.resolve() not in play_path.parents or not play_path.exists():
            raise HTTPException(400,'Selected playbook is not available. Sync the Git repository first.')

        queued=[]; blocked=[]
        for sid in ids:
            s=db.get(Server,sid)
            if not s:
                blocked.append(f'#{sid}: server not found'); continue
            if s.status=='Terminated':
                blocked.append(f'{s.hostname}: terminated'); continue
            if not s.instance_id or not s.aws_account_id or not s.aws_region:
                blocked.append(f'{s.hostname}: missing EC2/AWS account/region'); continue
            if not credential_for_server(db,s):
                blocked.append(f'{s.hostname}: no enabled SSH credential'); continue
            active=db.query(AnsibleJob).filter(AnsibleJob.server_id==sid,AnsibleJob.status.in_(['Queued','Claimed','Running'])).first()
            if active:
                blocked.append(f'{s.hostname}: job #{active.id} already running'); continue
            active_ami=db.query(AMIBackup).filter(AMIBackup.server_id==sid,AMIBackup.status.in_(['Creating','Pending'])).first()
            if active_ami:
                blocked.append(f'{s.hostname}: AMI backup already running ({active_ami.ami_id or "pending"})'); continue

            try:
                backup,_=create_ami_backup_for_server(db,s,u['username'])
                # The worker waits for THIS newly-created backup to become Available,
                # then starts the same normal Ansible patch workflow.
                job=AnsibleJob(
                    job_type='patch_after_backup',playbook_id=play.id,server_id=s.id,
                    status='Queued',requested_by=u['username'],
                    logs=f'ONE-CLICK PATCH queued.\nServer: {s.hostname} ({s.ip_address})\nPlaybook: {play.name}\nBackup: {backup.ami_id}\nWaiting for AMI to become Available before patching.\n'
                )
                db.add(job); db.flush()
                queued.append((s,job,backup))
                db.add(AuditLog(username=u['username'],action='ONE_CLICK_PATCH_QUEUED',server_id=s.id,
                    details=f'Queued one-click patch; playbook={play.name}; job={job.id}; AMI={backup.ami_id}; no_reboot=true'))
                threading.Thread(target=poll_ami_backup,args=(backup.id,),daemon=True).start()
            except Exception as exc:
                db.rollback()
                # Re-open the session transaction after a per-server failure.
                db.begin()
                blocked.append(f'{s.hostname}: backup request failed: {str(exc)[:300]}')

        if not queued:
            db.rollback()
            raise HTTPException(400,'No selected servers were queued. ' + (' | '.join(blocked) if blocked else ''))
        db.commit()
        job_ids=','.join(str(j.id) for _,j,_ in queued)
        msg=f'Queued {len(queued)} one-click patch job(s). AMI backups will complete first; patching starts automatically after each backup is Available.'
        if blocked: msg += f' {len(blocked)} server(s) were blocked.'
        return RedirectResponse('/patching?submitted=1&job_ids='+job_ids,303)
    finally:
        db.close()

@app.get('/servers',response_class=HTMLResponse)
def servers(request:Request,q:str='',risk:str='',sort:str='hostname',direction:str='asc',os_group:str=''):
    u=require_user(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal();today=date.today()
    try:
        cleanup_stale_jobs(db)
        query=db.query(Server)
        all_for_os = query.all()
        if os_group:
            allowed = {'Windows','RHEL','Amazon Linux','Ubuntu','SUSE','Oracle Linux','Debian','Other','Unknown'}
            if os_group not in allowed:
                raise HTTPException(400,'Invalid OS filter.')
            servers_list=[s for s in all_for_os if classify_os(s.os)==os_group]
        else:
            servers_list=None
        if q:
            t=f'%{q}%'
            query=query.filter(or_(Server.hostname.ilike(t),Server.ip_address.ilike(t),Server.instance_id.ilike(t),Server.aws_group_tag.ilike(t),Server.aws_account.ilike(t),Server.aws_account_id.ilike(t),Server.environment.ilike(t),Server.application.ilike(t),Server.os.ilike(t),Server.os_version.ilike(t)))
        valid_risks={'never','over30','over60','over90','overdue','due7'}
        if servers_list is None:
            servers_list=query.all()
        else:
            # Apply the free-text search on top of the canonical OS filter.
            if q:
                t=q.lower()
                servers_list=[s for s in servers_list if any(t in (str(v or '').lower()) for v in [s.hostname,s.ip_address,s.instance_id,s.aws_group_tag,s.aws_account,s.aws_account_id,s.environment,s.application,s.os,s.os_version])]
        if risk in valid_risks:
            filtered=[]
            for s in servers_list:
                latest=db.query(func.max(Patch.patch_date)).filter(Patch.server_id==s.id).scalar()
                days=(today-latest).days if latest else None
                match=(risk=='never' and latest is None) or (risk=='over30' and latest is not None and days>30) or (risk=='over60' and latest is not None and days>60) or (risk=='over90' and latest is not None and days>90) or (risk=='overdue' and s.next_patch_date is not None and s.next_patch_date<today) or (risk=='due7' and s.next_patch_date is not None and today<=s.next_patch_date<=today+timedelta(days=7))
                if match: filtered.append(s)
            servers_list=filtered
        # servers_list is already populated above, including any OS/free-text filters.

        sort_map={'hostname':Server.hostname,'status':Server.status,'aws_account':Server.aws_account,'patchgroup':Server.aws_group_tag,'ip':Server.ip_address,'instance_id':Server.instance_id,'environment':Server.environment,'next_patch_date':Server.next_patch_date}
        sort_col=sort_map.get(sort,Server.hostname)
        reverse=direction.lower()=='desc'
        if sort_col is not None:
            try: servers_list.sort(key=lambda s: ((getattr(s, sort_col.key) or '').lower() if isinstance(getattr(s, sort_col.key),str) else (getattr(s, sort_col.key) or date.min)), reverse=reverse)
            except Exception: servers_list.sort(key=lambda s:(s.hostname or '').lower(),reverse=reverse)

        sync_msg=request.query_params.get('sync','')
        risk_labels={'never':'Never patched','over30':'Older than 30 days','over60':'Older than 60 days','over90':'Older than 90 days','overdue':'Patch overdue','due7':'Due within 7 days'}
        return templates.TemplateResponse('servers.html',{'request':request,'user':u,'servers':servers_list[:500],'q':q,'risk':risk,'risk_label':risk_labels.get(risk),'sync_msg':sync_msg,'sort':sort,'direction':direction,'os_group':os_group})
    finally:db.close()

def form_page(request,server=None,error=None): return templates.TemplateResponse('server_form.html',{'request':request,'user':current_user(request),'server':server,'error':error})

@app.post('/servers/sync')
def sync_servers_from_aws(request:Request):
    u=require_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        results=sync_all_accounts_inventory(db,include_local=True)
        ok=[r for r in results if not r['error']]
        failed=[r for r in results if r['error']]
        total_seen=sum(r['seen'] for r in ok); total_added=sum(r['added'] for r in ok); total_updated=sum(r['updated'] for r in ok); total_patches=sum(r['patch_imported'] for r in ok)
        msg=f'Sync complete: {total_seen} AWS instances checked, {total_added} added, {total_updated} updated, {total_patches} PatchDate tags imported.'
        if failed: msg += ' Failed: ' + '; '.join(f"{r['account']}: {r['error']}" for r in failed)
        db.add(AuditLog(username=u['username'],action='AWS_SERVERS_SYNC',details=msg)); db.commit()
        return RedirectResponse('/servers?sync='+requests.utils.quote(msg),303)
    finally: db.close()

@app.get('/servers/new',response_class=HTMLResponse)
def new_page(request:Request):
    u=require_admin(request); return u if isinstance(u,RedirectResponse) else form_page(request)
@app.post('/servers/new')
def new_server(request:Request,hostname:str=Form(...),ip_address:str=Form(...),instance_id:str=Form(''),os_name:str=Form(''),os_version:str=Form(''),environment:str=Form(''),application:str=Form(''),owner:str=Form(''),aws_account:str=Form(''),aws_account_id:str=Form(''),aws_region:str=Form(''),aws_group_tag:str=Form(''),next_patch_date:str=Form(''),status:str=Form('Running')):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        h=clean(hostname);ip=clean(ip_address);iid=clean(instance_id)
        dup=db.query(Server).filter(or_(Server.hostname==h,Server.ip_address==ip,Server.instance_id==iid if iid else Server.id==-1)).first()
        if dup:return form_page(request,None,'Hostname, IP address, or EC2 instance ID already exists.')
        s=Server();fields(s,h,ip,iid,os_name,os_version,environment,application,owner,aws_account,aws_account_id,aws_region,aws_group_tag,next_patch_date,status);db.add(s);db.commit();db.refresh(s)
        db.add(AuditLog(username=u['username'],action='ADD_SERVER',server_id=s.id,details=f'Added {h}'));db.commit();return RedirectResponse(f'/servers/{s.id}',303)
    finally:db.close()

@app.get('/servers/{server_id}/edit',response_class=HTMLResponse)
def edit_page(request:Request,server_id:int):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        return form_page(request,s)
    finally:db.close()
@app.post('/servers/{server_id}/edit')
def edit_server(request:Request,server_id:int,ssh_credential_id:str=Form(''),hostname:str=Form(...),ip_address:str=Form(...),instance_id:str=Form(''),os_name:str=Form(''),os_version:str=Form(''),environment:str=Form(''),application:str=Form(''),owner:str=Form(''),aws_account:str=Form(''),aws_account_id:str=Form(''),aws_region:str=Form(''),aws_group_tag:str=Form(''),next_patch_date:str=Form(''),status:str=Form('Running')):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        h=clean(hostname);ip=clean(ip_address);iid=clean(instance_id)
        dup=db.query(Server).filter(Server.id!=server_id).filter(or_(Server.hostname==h,Server.ip_address==ip,Server.instance_id==iid if iid else Server.id==-1)).first()
        if dup:return form_page(request,s,'Hostname, IP address, or EC2 instance ID belongs to another server.')
        fields(s,h,ip,iid,os_name,os_version,environment,application,owner,aws_account,aws_account_id,aws_region,aws_group_tag,next_patch_date,status)
        db.add(AuditLog(username=u['username'],action='EDIT_SERVER',server_id=s.id,details=f'Updated {h}, status={s.status}'));s.ssh_credential_id=int(ssh_credential_id) if ssh_credential_id else None
        db.commit();return RedirectResponse(f'/servers/{s.id}',303)
    finally:db.close()

@app.post('/servers/{server_id}/delete')
def delete_server(request:Request,server_id:int):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        db.add(AuditLog(username=u['username'],action='DELETE_SERVER',details=f'Deleted {s.hostname} ({s.ip_address})'));db.delete(s);db.commit();return RedirectResponse('/servers',303)
    finally:db.close()
@app.post('/servers/delete-all')
def delete_all_servers(request:Request):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        count=db.query(Server).count();db.query(Patch).delete(synchronize_session=False);db.query(CVE).delete(synchronize_session=False);db.query(AAPJob).delete(synchronize_session=False);db.query(Server).delete(synchronize_session=False);db.add(AuditLog(username=u['username'],action='DELETE_ALL_SERVERS',details=f'Deleted all {count} servers and associated records'));db.commit();return RedirectResponse('/servers',303)
    finally:db.close()

@app.get('/servers/{server_id}',response_class=HTMLResponse)
def detail(request:Request,server_id:int):
    u=require_user(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        p=db.query(Patch).filter(Patch.server_id==server_id).order_by(Patch.patch_date.desc(),Patch.id.desc()).all(); cves=db.query(CVE).filter(CVE.server_id==server_id).order_by(CVE.status, CVE.severity.desc()).all(); jobs=db.query(AAPJob).filter(AAPJob.server_id==server_id).order_by(AAPJob.created_at.desc()).limit(10).all()
        creds=db.query(SSHCredential).filter(SSHCredential.enabled==True).order_by(SSHCredential.name.asc()).all()
        effective_cred=credential_for_server(db,s)
        backups=db.query(AMIBackup).filter(AMIBackup.server_id==server_id).order_by(AMIBackup.created_at.desc()).limit(10).all()
        playbooks=db.query(Playbook).order_by(Playbook.name.asc()).all()
        active_ansible_job=db.query(AnsibleJob).filter(AnsibleJob.server_id==server_id,AnsibleJob.status.in_(['Queued','Claimed','Running'])).order_by(AnsibleJob.id.desc()).first()
        latest_available_backup=db.query(AMIBackup).filter(AMIBackup.server_id==server_id,AMIBackup.status=='Available',AMIBackup.no_reboot==True).order_by(AMIBackup.completed_at.desc(),AMIBackup.created_at.desc()).first()
        # A reboot is pending whenever the latest successful patch says a reboot
        # is required and it has not yet been completed. Do not depend on the
        # exact result string/casing from older records.
        pending_reboot_patch=db.query(Patch).filter(
            Patch.server_id==server_id,
            Patch.reboot_required.is_(True),
            Patch.reboot_completed.is_(False)
        ).order_by(Patch.patch_date.desc(),Patch.id.desc()).first()
        can_reboot = u.get('role') in ('admin','main_admin') and pending_reboot_patch is not None
        return templates.TemplateResponse('server_detail.html',{
            'request':request,'user':u,'server':s,'patches':p,'latest':p if p else None,
            'ssh_credentials':creds,'effective_ssh_credential':effective_cred,
            'backups':backups,'playbooks':playbooks,'active_ansible_job':active_ansible_job,
            'latest_available_backup':latest_available_backup,'backup_gate_valid':backup_gate_is_valid(latest_available_backup),
            'pending_reboot_patch':pending_reboot_patch,'can_reboot':can_reboot
        })
    finally:db.close()

@app.post('/servers/{server_id}/patch-via-ansible')
def patch_via_ansible(request:Request,server_id:int,playbook_id:int=Form(...)):
    u=require_role(request,'main_admin','admin')
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        cleanup_stale_jobs(db)
        s=db.get(Server,server_id)
        if not s: raise HTTPException(404,'Server not found')
        if s.status == 'Terminated': raise HTTPException(400,'Cannot patch a terminated server.')
        p=db.get(Playbook,playbook_id)
        if not p: raise HTTPException(400,'Selected playbook was not found.')
        # Verify the playbook path belongs to a currently stored repository.
        repo=Path(os.environ.get('GIT_REPO_ROOT','/data/git-repos'))/str(p.repository_id)
        play=(repo/p.path).resolve()
        if repo.resolve() not in play.parents or not play.exists():
            raise HTTPException(400,'Selected playbook is not available. Sync the Git repository first.')

        cred=credential_for_server(db,s)
        if not cred:
            raise HTTPException(400,'No enabled SSH credential is mapped to this server or its PatchGroup. Configure SSH Credentials first.')

        # V11 safety gate: a successful AMI backup must exist before patch execution.
        backup=db.query(AMIBackup).filter(
            AMIBackup.server_id==server_id,
            AMIBackup.status=='Available',
            AMIBackup.no_reboot==True
        ).order_by(AMIBackup.completed_at.desc(),AMIBackup.created_at.desc()).first()
        if not backup:
            raise HTTPException(400,'Patch blocked: no successful No-Reboot AMI backup exists for this server. Click Back Up and wait until the backup is Available.')
        if not backup_gate_is_valid(backup):
            raise HTTPException(400,f'Patch blocked: the latest No-Reboot AMI backup is older than {BACKUP_GATE_HOURS} hours. Create a new backup before patching.')

        active=db.query(AnsibleJob).filter(
            AnsibleJob.server_id==server_id,
            AnsibleJob.status.in_(['Queued','Claimed','Running'])
        ).first()
        if active:
            raise HTTPException(409,f'An Ansible job is already running for this server (#{active.id}).')

        job=AnsibleJob(job_type='patch',playbook_id=p.id,server_id=s.id,status='Queued',requested_by=u['username'],logs=f'Queued patch job. Required backup: {backup.ami_id}\n')
        db.add(job)
        db.add(AuditLog(username=u['username'],action='PATCH_SERVER_ANSIBLE',server_id=s.id,
                        details=f'Queued Ansible job; playbook={p.name}; job_type=patch; backup={backup.ami_id}; credential={cred.name}'))
        db.commit()
        db.refresh(job)
        return RedirectResponse(f'/ansible/jobs/{job.id}',303)
    finally:
        db.close()

@app.post('/servers/{server_id}/reboot')
def reboot_server(request:Request,server_id:int):
    u=require_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        cleanup_stale_jobs(db)
        s=db.get(Server,server_id)
        if not s: raise HTTPException(404,'Server not found')
        latest=db.query(Patch).filter(Patch.server_id==server_id,Patch.result=='Success',Patch.reboot_required==True,Patch.reboot_completed==False).order_by(Patch.patch_date.desc(),Patch.id.desc()).first()
        if not latest: raise HTTPException(400,'No successful patch is currently marked as requiring a reboot.')
        active=db.query(AnsibleJob).filter(AnsibleJob.server_id==server_id,AnsibleJob.status.in_(['Queued','Claimed','Running'])).first()
        if active: raise HTTPException(409,f'Ansible job #{active.id} is still active.')
        cred=credential_for_server(db,s)
        if not cred: raise HTTPException(400,'No enabled SSH credential is mapped to this server or its PatchGroup.')
        reboot_play=db.query(Playbook).filter(
            (Playbook.name.ilike('%restart%')) | (Playbook.name.ilike('%reboot%')) |
            (Playbook.path.ilike('%restart%')) | (Playbook.path.ilike('%reboot%'))
        ).order_by(Playbook.name.asc()).first()
        job=AnsibleJob(
            job_type='reboot',
            playbook_id=reboot_play.id if reboot_play else None,
            server_id=server_id,
            status='Queued',
            requested_by=u['username'],
            logs=f'Queued reboot job for patch #{latest.id}. '+
                 (f'Using playbook: {reboot_play.name}.\n' if reboot_play else 'Using built-in reboot workflow.\n')
        )
        db.add(job)
        db.add(AuditLog(username=u['username'],action='REBOOT_SERVER',server_id=server_id,details=f'Queued controlled Ansible reboot for patch={latest.id}'))
        db.commit(); db.refresh(job)
        return RedirectResponse(f'/ansible/jobs/{job.id}',303)
    finally:
        db.close()

@app.post('/servers/{server_id}/patch')
def patch(request:Request,server_id:int,patch_date:str=Form(...),next_patch_date:str=Form(''),patch_type:str=Form('Monthly Patching'),os_version:str=Form(''),kernel_version:str=Form(''),performed_by:str=Form(''),source:str=Form('Manual'),result:str=Form('Success'),reboot_required:bool=Form(False),reboot_completed:bool=Form(False),aap_job_id:str=Form(''),comments:str=Form('')):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        p=Patch(server_id=server_id,patch_date=date.fromisoformat(patch_date),patch_type=clean(patch_type),os_version=clean(os_version),kernel_version=clean(kernel_version),performed_by=clean(performed_by),source=clean(source),result=clean(result) or 'Success',reboot_required=reboot_required,reboot_completed=reboot_completed,aap_job_id=clean(aap_job_id) or None,comments=clean(comments));db.add(p)
        if next_patch_date:s.next_patch_date=date.fromisoformat(next_patch_date)
        db.add(AuditLog(username=u['username'],action='ADD_PATCH',server_id=server_id,details=f'Patch recorded for {s.hostname}: {patch_date}, result={result}'));db.commit();return RedirectResponse(f'/servers/{server_id}',303)
    finally:db.close()

@app.post('/servers/{server_id}/cves')
def add_cve(request:Request,server_id:int,cve_id:str=Form(...),severity:str=Form('Medium'),package:str=Form(''),current_version:str=Form(''),fixed_version:str=Form(''),status:str=Form('Open'),detected_date:str=Form(''),remediated_date:str=Form(''),source:str=Form('Manual'),notes:str=Form('')):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        c=CVE(server_id=server_id,cve_id=clean(cve_id),severity=severity if severity in ('Critical','High','Medium','Low') else 'Medium',package=clean(package),current_version=clean(current_version),fixed_version=clean(fixed_version),status=status if status in ('Open','Remediated','Accepted Risk') else 'Open',detected_date=date.fromisoformat(detected_date) if detected_date else None,remediated_date=date.fromisoformat(remediated_date) if remediated_date else None,source=clean(source),notes=clean(notes));db.add(c);db.add(AuditLog(username=u['username'],action='ADD_CVE',server_id=server_id,details=f'Added {c.cve_id}'));db.commit();return RedirectResponse(f'/servers/{server_id}',303)
    finally:db.close()

@app.post('/cves/{cve_id}/remediate')
def remediate_cve(request:Request,cve_id:int):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        c=db.get(CVE,cve_id)
        if not c:raise HTTPException(404,'CVE not found')
        c.status='Remediated';c.remediated_date=date.today();db.add(AuditLog(username=u['username'],action='REMEDIATE_CVE',server_id=c.server_id,details=f'Remediated {c.cve_id}'));db.commit();return RedirectResponse(f'/servers/{c.server_id}',303)
    finally:db.close()

@app.post('/servers/{server_id}/patch-via-aap')
def patch_via_aap(request:Request,server_id:int):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    if not (AAP_URL and AAP_TOKEN and AAP_TEMPLATE_ID): raise HTTPException(503,'AAP integration is not configured')
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        payload={'extra_vars':{'portal_server_id':s.id,'hostname':s.hostname,'ip_address':s.ip_address,'instance_id':s.instance_id,'aws_account':s.aws_account,'environment':s.environment}}
        r=requests.post(f'{AAP_URL}/api/v2/job_templates/{AAP_TEMPLATE_ID}/launch/',headers={'Authorization':f'Bearer {AAP_TOKEN}','Content-Type':'application/json'},json=payload,verify=AAP_VERIFY_SSL,timeout=30)
        if r.status_code not in (200,201): raise HTTPException(502,f'AAP launch failed: HTTP {r.status_code}')
        data=r.json();job_id=str(data.get('job') or data.get('id') or '')
        if not job_id: raise HTTPException(502,'AAP did not return a job ID')
        db.add(AAPJob(server_id=s.id,job_id=job_id,status='Launched',launched_by=u['username']));db.add(AuditLog(username=u['username'],action='AAP_LAUNCH',server_id=s.id,details=f'Launched AAP job {job_id}'));db.commit();return RedirectResponse(f'/servers/{server_id}',303)
    finally:db.close()


@app.post('/servers/{server_id}/backup')
def backup_server(request:Request,server_id:int):
    u=require_role(request,'main_admin','admin')
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        cleanup_stale_jobs(db)
        s=db.get(Server,server_id)
        if not s: raise HTTPException(404,'Server not found')
        if s.status == 'Terminated': raise HTTPException(400,'Cannot create an AMI from a terminated EC2 instance.')
        if not s.instance_id: raise HTTPException(400,'This server does not have an EC2 Instance ID.')
        if not s.aws_account_id or not s.aws_region:
            raise HTTPException(400,'This server is missing AWS Account ID or AWS Region. Sync the server from AWS first.')
        active=db.query(AMIBackup).filter(
            AMIBackup.server_id==server_id,
            AMIBackup.status.in_(['Creating','Pending'])
        ).first()
        if active:
            db.add(AuditLog(username=u['username'],action='AMI_BACKUP_BLOCKED',server_id=server_id,
                            details=f'Backup request blocked by active AMI {active.ami_id or "pending"}.'))
            db.commit()
            raise HTTPException(409,f'An AMI backup is already running (AMI {active.ami_id or "pending"}).')
        backup,_=create_ami_backup_for_server(db,s,u['username'])
        threading.Thread(target=poll_ami_backup,args=(backup.id,),daemon=True).start()
        return RedirectResponse(f'/servers/{server_id}',303)
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(502,f'AMI backup request failed: {e}')
    finally:
        db.close()


@app.get('/servers/{server_id}/backups',response_class=HTMLResponse)
def server_backups(request:Request,server_id:int):
    u=require_user(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s: raise HTTPException(404,'Server not found')
        backups=db.query(AMIBackup).filter(AMIBackup.server_id==server_id).order_by(AMIBackup.created_at.desc()).limit(25).all()
        return templates.TemplateResponse('ami_backups.html',{'request':request,'user':u,'server':s,'backups':backups})
    finally:
        db.close()

@app.get('/users',response_class=HTMLResponse)
def users(request:Request):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:return templates.TemplateResponse('users.html',{'request':request,'user':u,'users':db.query(User).order_by(User.username).all()})
    finally:db.close()
@app.post('/users')
def create_user(request:Request,username:str=Form(...),password:str=Form(...),role:str=Form('readonly')):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    if len(clean(username))<3 or len(password)<8:raise HTTPException(400,'Username must be 3+ characters and password 8+ characters')
    db=SessionLocal()
    try:
        if db.query(User).filter_by(username=clean(username)).first():raise HTTPException(400,'Username already exists')
        role=role if role in ('readonly','admin') else 'readonly';db.add(User(username=clean(username),password_hash=pwd.hash(password),role=role));db.add(AuditLog(username=u['username'],action='CREATE_USER',details=f'Created {username} ({role})'));db.commit();return RedirectResponse('/users',303)
    finally:db.close()
@app.post('/users/{user_id}/delete')
def del_user(request:Request,user_id:int):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        x=db.get(User,user_id)
        if not x:raise HTTPException(404,'User not found')
        if x.id==u['id'] or x.username==ADMIN_USERNAME:raise HTTPException(400,'This user cannot be deleted')
        db.add(AuditLog(username=u['username'],action='DELETE_USER',details=f'Deleted user {x.username}'));db.delete(x);db.commit();return RedirectResponse('/users',303)
    finally:db.close()
@app.get('/profile/password',response_class=HTMLResponse)
def pw_page(request:Request):
    u=require_user(request);return u if isinstance(u,RedirectResponse) else templates.TemplateResponse('password.html',{'request':request,'user':u,'error':None,'success':None})
@app.post('/profile/password',response_class=HTMLResponse)
def pw_change(request:Request,current_password:str=Form(...),new_password:str=Form(...),confirm_password:str=Form(...)):
    u=require_user(request)
    if isinstance(u,RedirectResponse):return u
    if len(new_password)<8 or new_password!=confirm_password:return templates.TemplateResponse('password.html',{'request':request,'user':u,'error':'Passwords must match and be at least 8 characters.','success':None})
    db=SessionLocal()
    try:
        x=db.get(User,u['id'])
        if not x or not pwd.verify(current_password,x.password_hash):return templates.TemplateResponse('password.html',{'request':request,'user':u,'error':'Current password is incorrect.','success':None})
        x.password_hash=pwd.hash(new_password);db.add(AuditLog(username=u['username'],action='CHANGE_PASSWORD',details='User changed own password'));db.commit();return templates.TemplateResponse('password.html',{'request':request,'user':u,'error':None,'success':'Password changed successfully.'})
    finally:db.close()

@app.get('/import',response_class=HTMLResponse)
def import_page(request:Request):
    u=require_main_admin(request);return u if isinstance(u,RedirectResponse) else templates.TemplateResponse('import.html',{'request':request,'user':u,'result':None})
@app.post('/import',response_class=HTMLResponse)
async def import_csv(request:Request,csv_file:UploadFile=File(...)):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse):return u
    rows=csv.DictReader(io.StringIO((await csv_file.read()).decode('utf-8-sig')));db=SessionLocal();added=updated=skipped=0
    try:
        if not rows.fieldnames or not {'hostname','ip_address'}.issubset(rows.fieldnames):raise HTTPException(400,'CSV requires hostname and ip_address')
        for r in rows:
            h=clean(r.get('hostname'));ip=clean(r.get('ip_address'));iid=clean(r.get('instance_id'))
            if not h or not ip:skipped+=1;continue
            s=db.query(Server).filter(or_(Server.hostname==h,Server.ip_address==ip,Server.instance_id==iid if iid else Server.id==-1)).first()
            if not s:s=Server();added+=1
            else:updated+=1
            fields(s,h,ip,iid,r.get('os'),r.get('os_version'),r.get('environment'),r.get('application'),r.get('owner'),r.get('aws_account'),r.get('aws_account_id'),r.get('aws_region'),r.get('aws_group_tag'),r.get('next_patch_date'),r.get('status'));db.add(s)
        db.add(AuditLog(username=u['username'],action='IMPORT_CSV',details=f'added={added}, updated={updated}, skipped={skipped}'));db.commit();result=f'Import completed — Added: {added}, Updated: {updated}, Skipped: {skipped}';return templates.TemplateResponse('import.html',{'request':request,'user':u,'result':result})
    finally:db.close()

@app.get('/ansible/credentials',response_class=HTMLResponse)
def ssh_credentials_page(request:Request):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        creds=db.query(SSHCredential).order_by(SSHCredential.name.asc()).all()
        servers=db.query(Server).order_by(Server.hostname.asc()).all()
        return templates.TemplateResponse('ssh_credentials.html', {
            'request':request,'user':u,'credentials':creds,'servers':servers
        })
    finally:
        db.close()

@app.post('/ansible/credentials')
async def create_ssh_credential(
    request:Request,
    name:str=Form(...),
    username:str=Form(...),
    patch_group:str=Form(''),
    private_key:UploadFile=File(...),
    passphrase:str=Form('')
):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        name=clean(name); username=clean(username) or 'svc-ansible'; patch_group=clean(patch_group)
        if not name: raise HTTPException(400,'Credential name is required.')
        if db.query(SSHCredential).filter(func.lower(SSHCredential.name)==name.lower()).first():
            raise HTTPException(400,'A credential with this name already exists.')
        raw=await private_key.read()
        if len(raw)>100*1024:
            raise HTTPException(400,'Private key file is too large.')
        try:
            key_text=validate_private_key_text(raw.decode('utf-8'))
        except (UnicodeDecodeError,ValueError) as e:
            raise HTTPException(400,str(e))
        c=SSHCredential(
            name=name,username=username,
            patch_group=patch_group or None,
            private_key_encrypted=encrypt_secret(key_text),
            passphrase_encrypted=encrypt_optional_secret(passphrase)
        )
        db.add(c)
        db.add(AuditLog(username=u['username'],action='CREATE_SSH_CREDENTIAL',
                        details=f'Created SSH credential {name}; PatchGroup={patch_group or "-"}'))
        db.commit()
        return RedirectResponse('/ansible/credentials',303)
    finally:
        db.close()

@app.post('/ansible/credentials/{credential_id}/toggle')
def toggle_ssh_credential(request:Request,credential_id:int):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        c=db.get(SSHCredential,credential_id)
        if not c: raise HTTPException(404,'SSH credential not found')
        c.enabled=not c.enabled
        db.add(AuditLog(username=u['username'],action='TOGGLE_SSH_CREDENTIAL',
                        details=f'{c.name} enabled={c.enabled}'))
        db.commit()
        return RedirectResponse('/ansible/credentials',303)
    finally:
        db.close()

@app.post('/ansible/credentials/{credential_id}/delete')
def delete_ssh_credential(request:Request,credential_id:int):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        c=db.get(SSHCredential,credential_id)
        if not c: raise HTTPException(404,'SSH credential not found')
        # Clear server mappings before deleting the credential.
        db.query(Server).filter(Server.ssh_credential_id==c.id).update(
            {Server.ssh_credential_id:None}, synchronize_session=False)
        db.add(AuditLog(username=u['username'],action='DELETE_SSH_CREDENTIAL',
                        details=f'Deleted SSH credential {c.name}'))
        db.delete(c); db.commit()
        return RedirectResponse('/ansible/credentials',303)
    finally:
        db.close()

@app.get('/ansible/credentials/{credential_id}/download')
def blocked_ssh_credential_download(request:Request,credential_id:int):
    # Explicit endpoint that never returns the private key.
    u=require_user(request)
    if isinstance(u,RedirectResponse): return u
    raise HTTPException(403,'Private SSH keys cannot be downloaded from the portal.')

@app.post('/servers/{server_id}/ssh-credential')
def set_server_ssh_credential(request:Request,server_id:int,credential_id:str=Form('')):
    u=require_role(request,'main_admin','admin')
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s: raise HTTPException(404,'Server not found')
        cid=int(credential_id) if credential_id else None
        if cid and not db.get(SSHCredential,cid):
            raise HTTPException(400,'SSH credential not found.')
        s.ssh_credential_id=cid
        db.add(AuditLog(username=u['username'],action='SET_SERVER_SSH_CREDENTIAL',
                        server_id=s.id,details=f'credential_id={cid or "-"}'))
        db.commit()
        return RedirectResponse(f'/servers/{server_id}',303)
    finally:
        db.close()

@app.get('/ansible/repositories',response_class=HTMLResponse)
def ansible_repositories(request:Request):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        repos=db.query(GitRepository).order_by(GitRepository.name).all()
        playbooks=db.query(Playbook).order_by(Playbook.name).all()
        counts={r.id:db.query(Playbook).filter_by(repository_id=r.id).count() for r in repos}
        return templates.TemplateResponse('ansible_repositories.html',{'request':request,'user':u,'repos':repos,'playbooks':playbooks,'counts':counts,'error':None,'success':None})
    finally: db.close()

@app.post('/ansible/repositories')
def add_git_repository(request:Request,name:str=Form(...),url:str=Form(...),branch:str=Form('main'),username:str=Form('git'),token:str=Form(...)):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    nm=clean(name); repo_url=validate_git_url(url); br=clean(branch) or 'main'; usr=clean(username) or 'git'; pat=token.strip()
    if not pat: raise HTTPException(400,'GitHub Personal Access Token is required')
    db=SessionLocal()
    try:
        if db.query(GitRepository).filter_by(name=nm).first(): raise HTTPException(400,'Repository name already exists')
        # Validate before storing the credential.
        commit=git_test_connection(repo_url,br,usr,pat)
        r=GitRepository(name=nm,url=repo_url,branch=br,username=usr,token_encrypted=encrypt_secret(pat),provider='github')
        db.add(r);db.commit();db.refresh(r)
        db.add(AuditLog(username=u['username'],action='ADD_GIT_REPOSITORY',details=f'Added Git repository {nm} ({repo_url})'));db.commit()
        sync_git_repository(db,r)
        return RedirectResponse('/ansible/repositories',303)
    except RuntimeError as e:
        db.rollback(); raise HTTPException(502,f'Git connection failed: {e}')
    finally: db.close()

@app.post('/ansible/repositories/{repo_id}/test')
def test_git_repository(request:Request,repo_id:int):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        r=db.get(GitRepository,repo_id)
        if not r: raise HTTPException(404,'Git repository not found')
        token=decrypt_secret(r.token_encrypted);commit=git_test_connection(r.url,r.branch,r.username,token)
        r.sync_status='Connected';r.sync_message=f'Connection successful; branch {r.branch}, HEAD {commit[:12]}';db.commit();return RedirectResponse('/ansible/repositories',303)
    except RuntimeError as e:
        db.rollback();r=db.get(GitRepository,repo_id)
        if r:r.sync_status='Failed';r.sync_message=str(e);db.commit()
        raise HTTPException(502,f'Git connection failed: {e}')
    finally: db.close()

@app.post('/ansible/repositories/{repo_id}/sync')
def sync_git_repository_route(request:Request,repo_id:int):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        r=db.get(GitRepository,repo_id)
        if not r: raise HTTPException(404,'Git repository not found')
        count,commit=sync_git_repository(db,r)
        db.add(AuditLog(username=u['username'],action='SYNC_GIT_REPOSITORY',details=f'Synced {r.name}; playbooks={count}; commit={commit[:12]}'));db.commit();return RedirectResponse('/ansible/repositories',303)
    except RuntimeError as e:
        db.rollback();r=db.get(GitRepository,repo_id)
        if r:r.sync_status='Failed';r.sync_message=str(e);db.commit()
        raise HTTPException(502,f'Git sync failed: {e}')
    finally: db.close()

@app.post('/ansible/repositories/{repo_id}/delete')
def delete_git_repository(request:Request,repo_id:int):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        r=db.get(GitRepository,repo_id)
        if not r: raise HTTPException(404,'Git repository not found')
        repo_dir=Path(GIT_REPO_ROOT)/str(r.id)
        db.query(Playbook).filter_by(repository_id=r.id).delete(synchronize_session=False)
        db.add(AuditLog(username=u['username'],action='DELETE_GIT_REPOSITORY',details=f'Removed Git repository {r.name}'));db.delete(r);db.commit()
        if repo_dir.exists(): shutil.rmtree(repo_dir)
        return RedirectResponse('/ansible/repositories',303)
    finally: db.close()


@app.get('/ansible/jobs',response_class=HTMLResponse)
def ansible_jobs(request:Request):
    u=require_user(request); db=SessionLocal()
    try:
        jobs=db.query(AnsibleJob).order_by(AnsibleJob.created_at.desc()).limit(100).all()
        playbooks={p.id:p for p in db.query(Playbook).all()}
        return templates.TemplateResponse('ansible_jobs.html',{'request':request,'user':u,'jobs':jobs,'playbooks':playbooks})
    finally: db.close()

@app.post('/ansible/playbooks/{playbook_id}/validate')
def validate_playbook(request:Request,playbook_id:int):
    u=require_role(request,'main_admin','admin'); db=SessionLocal()
    try:
        p=db.get(Playbook,playbook_id)
        if not p: raise HTTPException(404,'Playbook not found')
        job=AnsibleJob(job_type='syntax_check',playbook_id=p.id,status='Queued',requested_by=u['username'])
        db.add(job); db.add(AuditLog(username=u['username'],action='QUEUE_ANSIBLE_VALIDATION',details=f'Queued syntax validation for {p.name}')); db.commit()
        return RedirectResponse('/ansible/jobs',303)
    finally: db.close()

@app.get('/ansible/jobs/{job_id}',response_class=HTMLResponse)
def ansible_job_detail(request:Request,job_id:int):
    u=require_user(request); db=SessionLocal()
    try:
        job=db.get(AnsibleJob,job_id)
        if not job: raise HTTPException(404,'Job not found')
        p=db.get(Playbook,job.playbook_id) if job.playbook_id else None
        return templates.TemplateResponse('ansible_job.html',{'request':request,'user':u,'job':job,'playbook':p})
    finally: db.close()

@app.get('/aws/accounts',response_class=HTMLResponse)
def aws_accounts(request:Request):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        accounts=db.query(AWSAccount).order_by(AWSAccount.name).all()
        counts={a.id:db.query(Server).filter(Server.aws_account_id==a.account_id).count() for a in accounts}
        return templates.TemplateResponse('aws_accounts.html',{'request':request,'user':u,'accounts':accounts,'counts':counts,'error':None,'success':None})
    finally: db.close()

@app.post('/aws/accounts')
def add_aws_account(request:Request,name:str=Form(...),account_id:str=Form(...),role_arn:str=Form(''),regions:str=Form(''),group_tag_key:str=Form('Group')):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        aid=clean(account_id); nm=clean(name); role=clean(role_arn) or None; regs=','.join([x.strip() for x in regions.split(',') if x.strip()]) or AWS_REGION
        if not aid.isdigit() or len(aid)!=12: raise HTTPException(400,'AWS Account ID must be 12 digits')
        if db.query(AWSAccount).filter_by(account_id=aid).first(): raise HTTPException(400,'AWS account already exists')
        a=AWSAccount(name=nm or aid,account_id=aid,role_arn=role,regions=regs,group_tag_key=clean(group_tag_key) or AWS_GROUP_TAG_KEY);db.add(a);db.add(AuditLog(username=u['username'],action='ADD_AWS_ACCOUNT',details=f'Added AWS account {aid}'));db.commit();return RedirectResponse('/aws/accounts',303)
    finally: db.close()

@app.post('/aws/accounts/{account_id}/test')
def test_aws_account(request:Request,account_id:int):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        a=db.get(AWSAccount,account_id)
        if not a: raise HTTPException(404,'AWS account configuration not found')
        session=aws_session_for(a); actual_id,actual_name=get_account_identity(session)
        if actual_id!=a.account_id: raise HTTPException(502,f'Role connected to account {actual_id}, expected {a.account_id}')
        a.sync_status='Connected'; a.sync_message=f'Connected as {actual_name} ({actual_id})'; db.commit();return RedirectResponse('/aws/accounts',303)
    except (BotoCoreError,ClientError) as e:
        db.rollback(); a=db.get(AWSAccount,account_id) if 'a' in locals() else None
        if a: a.sync_status='Failed';a.sync_message=str(e);db.commit()
        raise HTTPException(502,f'AWS connection failed: {e}')
    finally: db.close()

@app.post('/aws/accounts/{account_id}/sync')
def sync_one_aws_account(request:Request,account_id:int):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        a=db.get(AWSAccount,account_id)
        if not a: raise HTTPException(404,'AWS account configuration not found')
        seen,added,updated,patch_imported,patch_skipped=sync_aws_account(db,a);db.add(AuditLog(username=u['username'],action='AWS_ACCOUNT_SYNC',details=f'account={a.account_id}, seen={seen}, added={added}, updated={updated}'));db.commit();return RedirectResponse('/aws/accounts',303)
    except (BotoCoreError,ClientError) as e:
        db.rollback(); a=db.get(AWSAccount,account_id) if 'a' in locals() else None
        if a: a.sync_status='Failed';a.sync_message=str(e);db.commit()
        raise HTTPException(502,f'AWS sync failed: {e}')
    finally: db.close()

@app.post('/aws/accounts/sync-all')
def sync_all_aws_accounts(request:Request):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal();results=[]
    try:
        accounts=db.query(AWSAccount).filter(AWSAccount.enabled==True).all()
        for a in accounts:
            try:
                seen,added,updated,patch_imported,patch_skipped=sync_aws_account(db,a);results.append(f'{a.name}: {seen} seen, {added} added, {updated} updated')
                db.add(AuditLog(username=u['username'],action='AWS_ACCOUNT_SYNC',details=f'account={a.account_id}, seen={seen}, added={added}, updated={updated}'))
                db.commit()
            except Exception as e:
                db.rollback();a=db.get(AWSAccount,a.id);a.sync_status='Failed';a.sync_message=str(e);db.commit();results.append(f'{a.name}: FAILED - {e}')
        return RedirectResponse('/aws/accounts',303)
    finally: db.close()

@app.post('/aws/accounts/{account_id}/delete')
def delete_aws_account(request:Request,account_id:int):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        a=db.get(AWSAccount,account_id)
        if not a: raise HTTPException(404,'AWS account configuration not found')
        # Do not delete server records; they retain their account ID/history.
        db.add(AuditLog(username=u['username'],action='DELETE_AWS_ACCOUNT',details=f'Removed AWS account config {a.account_id}; server records retained'));db.delete(a);db.commit();return RedirectResponse('/aws/accounts',303)
    finally: db.close()

@app.post('/aws/sync')
def aws_sync_legacy(request:Request):
    # Backward-compatible button: sync the local account using the EC2 instance role.
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        a=db.query(AWSAccount).filter_by(account_id=boto3.client('sts').get_caller_identity()['Account']).first()
        if not a:
            aid,aname=get_account_identity(boto3.Session())
            a=AWSAccount(name=aname,account_id=aid,role_arn=None,regions=AWS_REGION,group_tag_key=AWS_GROUP_TAG_KEY);db.add(a);db.commit();db.refresh(a)
        sync_aws_account(db,a);db.add(AuditLog(username=u['username'],action='AWS_SYNC',details=f'local account={a.account_id}'));db.commit();return RedirectResponse('/servers',303)
    finally: db.close()

@app.get('/api/health')
def health():return {'status':'ok','version':'7.0'}
@app.get('/api/v1/servers/{server_id}')
def api_get(request:Request,server_id:int):
    api_authorized(request);db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        latest=db.query(Patch).filter(Patch.server_id==server_id).order_by(Patch.patch_date.desc(),Patch.id.desc()).first();return {'id':s.id,'hostname':s.hostname,'ip_address':s.ip_address,'instance_id':s.instance_id,'os':s.os,'os_version':s.os_version,'environment':s.environment,'application':s.application,'owner':s.owner,'aws_account':s.aws_account,'aws_account_id':s.aws_account_id,'aws_region':s.aws_region,'aws_group_tag':s.aws_group_tag,'next_patch_date':s.next_patch_date.isoformat() if s.next_patch_date else None,'status':s.status,'latest_patch_date':latest.patch_date.isoformat() if latest else None}
    finally:db.close()
@app.post('/api/v1/servers/{server_id}/patch')
def api_patch(request:Request):
    api_authorized(request)
    # Read JSON manually because this endpoint is intended for AAP callbacks.
    import asyncio
    raise HTTPException(501,'Use /api/v1/patch-results for AAP callbacks')
@app.post('/api/v1/patch-results')
async def api_patch_result(request:Request):
    api_authorized(request); data=await request.json();db=SessionLocal()
    try:
        sid=data.get('server_id');s=db.get(Server,int(sid)) if sid else None
        if not s: raise HTTPException(404,'Server not found')
        p=Patch(server_id=s.id,patch_date=date.fromisoformat(data.get('patch_date',date.today().isoformat())),patch_type=clean(data.get('patch_type','Monthly Patching')),os_version=clean(data.get('os_version','')),kernel_version=clean(data.get('kernel_version','')),performed_by=clean(data.get('performed_by','AAP')),source=clean(data.get('source','AAP')),result=clean(data.get('result','Success')),reboot_required=bool(data.get('reboot_required',False)),reboot_completed=bool(data.get('reboot_completed',False)),aap_job_id=clean(str(data.get('aap_job_id',''))) or None,comments=clean(data.get('comments','')));db.add(p)
        if data.get('next_patch_date'):s.next_patch_date=date.fromisoformat(data['next_patch_date'])
        job_id=str(data.get('aap_job_id',''))
        if job_id:
            j=db.query(AAPJob).filter(AAPJob.job_id==job_id).first()
            if j:j.status=clean(data.get('result','Success'))
        db.add(AuditLog(username='API',action='API_PATCH_RESULT',server_id=s.id,details=f'AAP patch result for {s.hostname}: {p.result}'));db.commit();return {'status':'recorded','server_id':s.id,'patch_date':p.patch_date.isoformat(),'result':p.result}
    finally:db.close()
