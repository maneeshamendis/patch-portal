# Server Patch Portal V8

V8 adds an Ansible worker and persistent job queue on top of V7 Git repository/playbook discovery.

## V8 features
- Private Git repositories with encrypted PATs
- Playbook discovery
- Ansible worker container
- Persistent Ansible job queue in PostgreSQL
- Playbook syntax validation jobs
- Live-ish job output page with auto-refresh
- Audit entry when validation is queued

## Not yet enabled
Remote server execution requires the V9 SSH credential layer. Do not put private keys in Git or the database as plaintext.

## Deployment
Preserve the existing PostgreSQL volume. Do not use `docker compose down -v`.
