import csv, io, os, secrets, json
from datetime import datetime, timedelta, date
from typing import Optional

import boto3
import requests
from botocore.exceptions import BotoCoreError, ClientError
from fastapi import FastAPI, Request, Form, UploadFile, File, HTTPException, Depends
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from passlib.context import CryptContext
from sqlalchemy import create_engine, String, Integer, Date, DateTime, ForeignKey, Text, Boolean, func, or_, Float, Index
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker

DATABASE_URL=os.environ['DATABASE_URL']; SECRET_KEY=os.environ['SECRET_KEY']
ADMIN_USERNAME=os.environ.get('ADMIN_USERNAME','admin'); ADMIN_PASSWORD=os.environ.get('ADMIN_PASSWORD','ChangeMeNow!123')
SESSION_DAYS=int(os.environ.get('SESSION_DAYS','1'))
AWS_REGION=os.environ.get('AWS_REGION','eu-west-1')
AWS_GROUP_TAG_KEY=os.environ.get('AWS_GROUP_TAG_KEY','Group')
AAP_URL=os.environ.get('AAP_URL','').rstrip('/')
AAP_TOKEN=os.environ.get('AAP_TOKEN','')
AAP_TEMPLATE_ID=os.environ.get('AAP_TEMPLATE_ID','')
AAP_VERIFY_SSL=os.environ.get('AAP_VERIFY_SSL','true').lower()=='true'
PORTAL_API_TOKEN=os.environ.get('PORTAL_API_TOKEN','')

engine=create_engine(DATABASE_URL,pool_pre_ping=True)
SessionLocal=sessionmaker(bind=engine,autoflush=False,autocommit=False)
pwd=CryptContext(schemes=['bcrypt'],deprecated='auto')
serializer=URLSafeTimedSerializer(SECRET_KEY)
app=FastAPI(title='Server Patch Portal',version='5.0')
templates=Jinja2Templates(directory='templates')

class Base(DeclarativeBase): pass
class User(Base):
    __tablename__='users'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    username:Mapped[str]=mapped_column(String(100),unique=True,index=True)
    password_hash:Mapped[str]=mapped_column(String(255))
    role:Mapped[str]=mapped_column(String(30),default='readonly')
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
class Server(Base):
    __tablename__='servers'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    hostname:Mapped[str]=mapped_column(String(255),index=True)
    ip_address:Mapped[str]=mapped_column(String(64),index=True)
    instance_id:Mapped[str|None]=mapped_column(String(100),nullable=True,index=True)
    os:Mapped[str|None]=mapped_column(String(100))
    os_version:Mapped[str|None]=mapped_column(String(100))
    environment:Mapped[str|None]=mapped_column(String(100))
    application:Mapped[str|None]=mapped_column(String(255))
    owner:Mapped[str|None]=mapped_column(String(255))
    aws_account:Mapped[str|None]=mapped_column(String(255))
    aws_account_id:Mapped[str|None]=mapped_column(String(30))
    aws_region:Mapped[str|None]=mapped_column(String(50))
    aws_group_tag:Mapped[str|None]=mapped_column(String(255))
    next_patch_date:Mapped[date|None]=mapped_column(Date,nullable=True)
    status:Mapped[str]=mapped_column(String(30),default='Running')
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    updated_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)
    patches=relationship('Patch',back_populates='server',cascade='all, delete-orphan')
    cves=relationship('CVE',back_populates='server',cascade='all, delete-orphan')
class Patch(Base):
    __tablename__='patch_history'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    server_id:Mapped[int]=mapped_column(ForeignKey('servers.id'),index=True)
    patch_date:Mapped[date]=mapped_column(Date)
    patch_type:Mapped[str|None]=mapped_column(String(100))
    os_version:Mapped[str|None]=mapped_column(String(100))
    kernel_version:Mapped[str|None]=mapped_column(String(255))
    performed_by:Mapped[str|None]=mapped_column(String(255))
    source:Mapped[str|None]=mapped_column(String(100))
    result:Mapped[str|None]=mapped_column(String(30),default='Success')
    reboot_required:Mapped[bool]=mapped_column(Boolean,default=False)
    reboot_completed:Mapped[bool]=mapped_column(Boolean,default=False)
    aap_job_id:Mapped[str|None]=mapped_column(String(100))
    comments:Mapped[str|None]=mapped_column(Text)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    server=relationship('Server',back_populates='patches')
class CVE(Base):
    __tablename__='cves'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    server_id:Mapped[int]=mapped_column(ForeignKey('servers.id'),index=True)
    cve_id:Mapped[str]=mapped_column(String(50),index=True)
    severity:Mapped[str]=mapped_column(String(20),default='Medium')
    package:Mapped[str|None]=mapped_column(String(255))
    current_version:Mapped[str|None]=mapped_column(String(255))
    fixed_version:Mapped[str|None]=mapped_column(String(255))
    status:Mapped[str]=mapped_column(String(30),default='Open')
    detected_date:Mapped[date|None]=mapped_column(Date)
    remediated_date:Mapped[date|None]=mapped_column(Date)
    source:Mapped[str|None]=mapped_column(String(100))
    notes:Mapped[str|None]=mapped_column(Text)
    server=relationship('Server',back_populates='cves')
class AAPJob(Base):
    __tablename__='aap_jobs'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    server_id:Mapped[int]=mapped_column(ForeignKey('servers.id'),index=True)
    job_id:Mapped[str]=mapped_column(String(100),index=True)
    status:Mapped[str]=mapped_column(String(30),default='Launched')
    launched_by:Mapped[str]=mapped_column(String(100))
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
class AWSAccount(Base):
    __tablename__='aws_accounts'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    name:Mapped[str]=mapped_column(String(255))
    account_id:Mapped[str]=mapped_column(String(30),unique=True,index=True)
    role_arn:Mapped[str|None]=mapped_column(String(255),nullable=True)
    regions:Mapped[str]=mapped_column(Text,default='eu-west-1')
    group_tag_key:Mapped[str]=mapped_column(String(100),default='Group')
    enabled:Mapped[bool]=mapped_column(Boolean,default=True)
    last_sync:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
    sync_status:Mapped[str]=mapped_column(String(30),default='Not Synced')
    sync_message:Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    updated_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)

class AuditLog(Base):
    __tablename__='audit_log'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    username:Mapped[str]=mapped_column(String(100))
    action:Mapped[str]=mapped_column(String(100))
    server_id:Mapped[int|None]=mapped_column(Integer,nullable=True)
    details:Mapped[str|None]=mapped_column(Text)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

def clean(x): return (x or '').strip()

def migrate_db():
    stmts=[
      "ALTER TABLE servers ADD COLUMN IF NOT EXISTS aws_account_id VARCHAR(30)",
      "ALTER TABLE servers ADD COLUMN IF NOT EXISTS aws_region VARCHAR(50)",
      "ALTER TABLE patch_history ADD COLUMN IF NOT EXISTS result VARCHAR(30) DEFAULT 'Success'",
      "ALTER TABLE patch_history ADD COLUMN IF NOT EXISTS reboot_required BOOLEAN DEFAULT FALSE",
      "ALTER TABLE patch_history ADD COLUMN IF NOT EXISTS reboot_completed BOOLEAN DEFAULT FALSE",
      "ALTER TABLE patch_history ADD COLUMN IF NOT EXISTS aap_job_id VARCHAR(100)",
      "ALTER TABLE servers DROP CONSTRAINT IF EXISTS servers_hostname_key",
      "ALTER TABLE servers DROP CONSTRAINT IF EXISTS servers_ip_address_key",
      "ALTER TABLE servers DROP CONSTRAINT IF EXISTS servers_instance_id_key",
      "CREATE INDEX IF NOT EXISTS ix_servers_aws_account_id ON servers (aws_account_id)",
      "CREATE INDEX IF NOT EXISTS ix_servers_aws_region ON servers (aws_region)"
    ]
    with engine.begin() as c:
        for stmt in stmts:
            try: c.exec_driver_sql(stmt)
            except Exception: pass

def init_db():
    Base.metadata.create_all(engine); migrate_db(); db=SessionLocal()
    try:
        x=db.query(User).filter_by(username=ADMIN_USERNAME).first()
        if not x: db.add(User(username=ADMIN_USERNAME,password_hash=pwd.hash(ADMIN_PASSWORD),role='main_admin')); db.commit()
        elif x.role!='main_admin': x.role='main_admin'; db.commit()
    finally: db.close()

def current_user(request):
    t=request.cookies.get('session')
    if not t:return None
    try:return serializer.loads(t,max_age=SESSION_DAYS*86400)
    except (BadSignature,SignatureExpired):return None

def require_user(request):
    u=current_user(request); return u if u else RedirectResponse('/login',303)
def require_admin(request):
    u=require_user(request)
    if isinstance(u,RedirectResponse):return u
    if u.get('role') not in ('admin','main_admin'):raise HTTPException(403,'Administrator access required')
    return u
def require_main_admin(request):
    u=require_user(request)
    if isinstance(u,RedirectResponse):return u
    if u.get('role')!='main_admin':raise HTTPException(403,'Main administrator access required')
    return u

def api_authorized(request:Request):
    if not PORTAL_API_TOKEN: raise HTTPException(503,'API token is not configured')
    auth=request.headers.get('Authorization','')
    if not auth.startswith('Bearer '): raise HTTPException(401,'Bearer token required')
    if not secrets.compare_digest(auth[7:],PORTAL_API_TOKEN): raise HTTPException(401,'Invalid API token')

def status_normalize(v):
    v=clean(v)
    m={'running':'Running','stopped':'Stopped','terminated':'Terminated','pending':'Pending','stopping':'Stopping','shutting-down':'Shutting Down'}
    return m.get(v.lower(),v if v else 'Running')

def aws_session_for(account:AWSAccount):
    if account.role_arn:
        sts=boto3.client('sts',region_name=AWS_REGION)
        assumed=sts.assume_role(RoleArn=account.role_arn,RoleSessionName=f'patch-portal-{account.id}')['Credentials']
        return boto3.Session(
            aws_access_key_id=assumed['AccessKeyId'],
            aws_secret_access_key=assumed['SecretAccessKey'],
            aws_session_token=assumed['SessionToken'],
            region_name=AWS_REGION
        )
    return boto3.Session(region_name=AWS_REGION)

def get_account_identity(session):
    sts=session.client('sts')
    account_id=sts.get_caller_identity()['Account']
    account_name=account_id
    try:
        aliases=session.client('iam').list_account_aliases().get('AccountAliases',[])
        if aliases: account_name=aliases[0]
    except Exception: pass
    return account_id,account_name

def parse_patch_date_tag(value):
    value=clean(value)
    if not value:
        return None
    formats=['%Y-%m-%d','%Y/%m/%d','%d/%m/%Y','%d-%m-%Y','%d-%b-%Y','%d-%b-%y','%d %b %Y','%Y-%m-%dT%H:%M:%S','%Y-%m-%dT%H:%M:%SZ']
    for fmt in formats:
        try:
            return datetime.strptime(value,fmt).date()
        except ValueError:
            pass
    try:
        return date.fromisoformat(value[:10])
    except ValueError:
        return None

def ensure_local_aws_account(db):
    session=boto3.Session(region_name=AWS_REGION)
    aid,aname=get_account_identity(session)
    a=db.query(AWSAccount).filter_by(account_id=aid).first()
    if not a:
        a=AWSAccount(name=aname,account_id=aid,role_arn=None,regions=AWS_REGION,group_tag_key=AWS_GROUP_TAG_KEY)
        db.add(a); db.commit(); db.refresh(a)
    return a

def sync_all_accounts_inventory(db, include_local=True):
    if include_local:
        local=ensure_local_aws_account(db)
    else:
        local=None
    accounts=db.query(AWSAccount).filter(AWSAccount.enabled==True).order_by(AWSAccount.name).all()
    results=[]
    for a in accounts:
        try:
            seen,added,updated,patch_imported,patch_skipped=sync_aws_account(db,a)
            db.add(AuditLog(username='system',action='AWS_ACCOUNT_SYNC',details=f'account={a.account_id}, seen={seen}, added={added}, updated={updated}, patch_imported={patch_imported}'))
            db.commit()
            results.append({'account':a.name,'account_id':a.account_id,'seen':seen,'added':added,'updated':updated,'patch_imported':patch_imported,'patch_skipped':patch_skipped,'error':None})
        except Exception as e:
            db.rollback()
            a=db.get(AWSAccount,a.id)
            if a:
                a.sync_status='Failed'; a.sync_message=str(e); db.commit()
            results.append({'account':a.name if a else 'Unknown','account_id':a.account_id if a else '','seen':0,'added':0,'updated':0,'patch_imported':0,'patch_skipped':0,'error':str(e)})
    return results

def sync_aws_account(db, account:AWSAccount, region_list=None):
    session=aws_session_for(account)
    account_id,account_name=get_account_identity(session)
    regions=region_list or [r.strip() for r in (account.regions or '').split(',') if r.strip()] or [AWS_REGION]
    seen=added=updated=patch_imported=patch_skipped=0
    for region in regions:
        ec2=session.client('ec2',region_name=region)
        paginator=ec2.get_paginator('describe_instances')
        for page in paginator.paginate():
            for res in page.get('Reservations',[]):
                for i in res.get('Instances',[]):
                    iid=i.get('InstanceId')
                    if not iid: continue
                    seen+=1
                    tags={x.get('Key'):x.get('Value','') for x in i.get('Tags',[]) if x.get('Key')}
                    h=tags.get('Name') or i.get('PrivateDnsName') or iid
                    ip=i.get('PrivateIpAddress') or ''
                    if not ip: continue
                    s=db.query(Server).filter(Server.aws_account_id==account_id,Server.aws_region==region,Server.instance_id==iid).first()
                    if not s:
                        s=db.query(Server).filter(Server.aws_account_id==account_id,Server.aws_region==region,Server.hostname==h).first()
                    if not s:
                        s=db.query(Server).filter(Server.aws_account_id==account_id,Server.aws_region==region,Server.ip_address==ip).first()
                    is_new=s is None
                    if is_new:
                        s=Server(); added+=1
                    else: updated+=1

                    current_next=s.next_patch_date.isoformat() if s.next_patch_date else ''
                    fields(s,h,ip,iid,i.get('PlatformDetails') or i.get('Platform') or '',s.os_version,tags.get('Environment',''),tags.get('Application',''),tags.get('Owner',''),account_name,account_id,region,tags.get(account.group_tag_key or AWS_GROUP_TAG_KEY,''),current_next,status_normalize(i.get('State',{}).get('Name','')))
                    db.add(s)
                    db.flush()

                    patch_tag=tags.get('PatchDate','')
                    if patch_tag:
                        patch_date=parse_patch_date_tag(patch_tag)
                        if patch_date:
                            existing=db.query(Patch).filter(Patch.server_id==s.id,Patch.patch_date==patch_date).first()
                            if not existing:
                                db.add(Patch(server_id=s.id,patch_date=patch_date,patch_type='AWS PatchDate Tag',source='AWS Tag',result='Success',performed_by='AWS',comments=f'Imported from EC2 tag PatchDate={patch_tag}'))
                                patch_imported+=1
                        else:
                            patch_skipped+=1
    account.last_sync=datetime.utcnow(); account.sync_status='Success'; account.sync_message=f'Synced {seen} instances; added {added}, updated {updated}, PatchDate imported {patch_imported}' + (f', invalid PatchDate skipped {patch_skipped}' if patch_skipped else '')
    return seen,added,updated,patch_imported,patch_skipped

def fields(s,hostname,ip,instance,osn,osv,env,appn,owner,acct,acctid,region,group,nextd,status):
    s.hostname=clean(hostname); s.ip_address=clean(ip); s.instance_id=clean(instance) or None
    s.os=clean(osn); s.os_version=clean(osv); s.environment=clean(env); s.application=clean(appn); s.owner=clean(owner)
    s.aws_account=clean(acct); s.aws_account_id=clean(acctid); s.aws_region=clean(region); s.aws_group_tag=clean(group)
    s.next_patch_date=date.fromisoformat(nextd) if nextd else None; s.status=status_normalize(status)

@app.on_event('startup')
def startup(): init_db()

@app.get('/login',response_class=HTMLResponse)
def login_page(request:Request): return RedirectResponse('/',303) if current_user(request) else templates.TemplateResponse('login.html',{'request':request,'error':None})
@app.post('/login',response_class=HTMLResponse)
def login(request:Request,username:str=Form(...),password:str=Form(...)):
    db=SessionLocal()
    try:
        u=db.query(User).filter_by(username=clean(username)).first()
        if not u or not pwd.verify(password,u.password_hash): return templates.TemplateResponse('login.html',{'request':request,'error':'Invalid username or password'})
        r=RedirectResponse('/',303); r.set_cookie('session',serializer.dumps({'id':u.id,'username':u.username,'role':u.role}),httponly=True,samesite='lax',max_age=SESSION_DAYS*86400,secure=False); return r
    finally: db.close()
@app.get('/logout')
def logout(): r=RedirectResponse('/login',303);r.delete_cookie('session');return r

@app.get('/',response_class=HTMLResponse)
def dashboard(request:Request):
    u=require_user(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal();today=date.today()
    try:
        all_servers=db.query(Server).all(); total=len(all_servers)
        running=sum(s.status=='Running' for s in all_servers); stopped=sum(s.status=='Stopped' for s in all_servers); terminated=sum(s.status=='Terminated' for s in all_servers)
        never=[];over30=[];over60=[];over90=[];next_overdue=[];next_7=[]
        for s in all_servers:
            latest=db.query(func.max(Patch.patch_date)).filter(Patch.server_id==s.id).scalar(); days=(today-latest).days if latest else None
            if latest is None:never.append(s)
            elif days>30:over30.append(s)
            if latest and days>60:over60.append(s)
            if latest and days>90:over90.append(s)
            if s.next_patch_date:
                if s.next_patch_date<today:next_overdue.append(s)
                elif s.next_patch_date<=today+timedelta(days=7):next_7.append(s)
        compliant=total-len(never)-len(over30); compliance=round(compliant/total*100,1) if total else 0
        cves=db.query(CVE).filter(CVE.status=='Open').all(); crit=sum(x.severity=='Critical' for x in cves); high=sum(x.severity=='High' for x in cves)
        return templates.TemplateResponse('dashboard.html',{'request':request,'user':u,'total':total,'running':running,'stopped':stopped,'terminated':terminated,'compliance':compliance,'month':db.query(Patch).filter(Patch.patch_date>=today.replace(day=1)).count(),'never':len(never),'over30':len(over30),'over60':len(over60),'over90':len(over90),'next_overdue':len(next_overdue),'next_7':len(next_7),'no_instance':sum(not s.instance_id for s in all_servers),'no_account':sum(not s.aws_account for s in all_servers),'no_group':sum(not s.aws_group_tag for s in all_servers),'open_cves':len(cves),'critical_cves':crit,'high_cves':high,'attention':[(s,db.query(func.max(Patch.patch_date)).filter(Patch.server_id==s.id).scalar()) for s in (never+over30)[:100]]})
    finally:db.close()

@app.get('/servers',response_class=HTMLResponse)
def servers(request:Request,q:str=''):
    u=require_user(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        query=db.query(Server)
        if q:
            t=f'%{q}%'; query=query.filter(or_(Server.hostname.ilike(t),Server.ip_address.ilike(t),Server.instance_id.ilike(t),Server.aws_group_tag.ilike(t),Server.aws_account.ilike(t),Server.aws_account_id.ilike(t),Server.environment.ilike(t),Server.application.ilike(t)))
        sync_msg=request.query_params.get('sync','')
        return templates.TemplateResponse('servers.html',{'request':request,'user':u,'servers':query.order_by(Server.hostname).limit(500).all(),'q':q,'sync_msg':sync_msg})
    finally:db.close()

def form_page(request,server=None,error=None): return templates.TemplateResponse('server_form.html',{'request':request,'user':current_user(request),'server':server,'error':error})

@app.post('/servers/sync')
def sync_servers_from_aws(request:Request):
    u=require_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        results=sync_all_accounts_inventory(db,include_local=True)
        ok=[r for r in results if not r['error']]
        failed=[r for r in results if r['error']]
        total_seen=sum(r['seen'] for r in ok); total_added=sum(r['added'] for r in ok); total_updated=sum(r['updated'] for r in ok); total_patches=sum(r['patch_imported'] for r in ok)
        msg=f'Sync complete: {total_seen} AWS instances checked, {total_added} added, {total_updated} updated, {total_patches} PatchDate tags imported.'
        if failed: msg += ' Failed: ' + '; '.join(f"{r['account']}: {r['error']}" for r in failed)
        db.add(AuditLog(username=u['username'],action='AWS_SERVERS_SYNC',details=msg)); db.commit()
        return RedirectResponse('/servers?sync='+requests.utils.quote(msg),303)
    finally: db.close()

@app.get('/servers/new',response_class=HTMLResponse)
def new_page(request:Request):
    u=require_admin(request); return u if isinstance(u,RedirectResponse) else form_page(request)
@app.post('/servers/new')
def new_server(request:Request,hostname:str=Form(...),ip_address:str=Form(...),instance_id:str=Form(''),os_name:str=Form(''),os_version:str=Form(''),environment:str=Form(''),application:str=Form(''),owner:str=Form(''),aws_account:str=Form(''),aws_account_id:str=Form(''),aws_region:str=Form(''),aws_group_tag:str=Form(''),next_patch_date:str=Form(''),status:str=Form('Running')):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        h=clean(hostname);ip=clean(ip_address);iid=clean(instance_id)
        dup=db.query(Server).filter(or_(Server.hostname==h,Server.ip_address==ip,Server.instance_id==iid if iid else Server.id==-1)).first()
        if dup:return form_page(request,None,'Hostname, IP address, or EC2 instance ID already exists.')
        s=Server();fields(s,h,ip,iid,os_name,os_version,environment,application,owner,aws_account,aws_account_id,aws_region,aws_group_tag,next_patch_date,status);db.add(s);db.commit();db.refresh(s)
        db.add(AuditLog(username=u['username'],action='ADD_SERVER',server_id=s.id,details=f'Added {h}'));db.commit();return RedirectResponse(f'/servers/{s.id}',303)
    finally:db.close()

@app.get('/servers/{server_id}/edit',response_class=HTMLResponse)
def edit_page(request:Request,server_id:int):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        return form_page(request,s)
    finally:db.close()
@app.post('/servers/{server_id}/edit')
def edit_server(request:Request,server_id:int,hostname:str=Form(...),ip_address:str=Form(...),instance_id:str=Form(''),os_name:str=Form(''),os_version:str=Form(''),environment:str=Form(''),application:str=Form(''),owner:str=Form(''),aws_account:str=Form(''),aws_account_id:str=Form(''),aws_region:str=Form(''),aws_group_tag:str=Form(''),next_patch_date:str=Form(''),status:str=Form('Running')):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        h=clean(hostname);ip=clean(ip_address);iid=clean(instance_id)
        dup=db.query(Server).filter(Server.id!=server_id).filter(or_(Server.hostname==h,Server.ip_address==ip,Server.instance_id==iid if iid else Server.id==-1)).first()
        if dup:return form_page(request,s,'Hostname, IP address, or EC2 instance ID belongs to another server.')
        fields(s,h,ip,iid,os_name,os_version,environment,application,owner,aws_account,aws_account_id,aws_region,aws_group_tag,next_patch_date,status)
        db.add(AuditLog(username=u['username'],action='EDIT_SERVER',server_id=s.id,details=f'Updated {h}, status={s.status}'));db.commit();return RedirectResponse(f'/servers/{s.id}',303)
    finally:db.close()

@app.post('/servers/{server_id}/delete')
def delete_server(request:Request,server_id:int):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        db.add(AuditLog(username=u['username'],action='DELETE_SERVER',details=f'Deleted {s.hostname} ({s.ip_address})'));db.delete(s);db.commit();return RedirectResponse('/servers',303)
    finally:db.close()
@app.post('/servers/delete-all')
def delete_all_servers(request:Request):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        count=db.query(Server).count();db.query(Patch).delete(synchronize_session=False);db.query(CVE).delete(synchronize_session=False);db.query(AAPJob).delete(synchronize_session=False);db.query(Server).delete(synchronize_session=False);db.add(AuditLog(username=u['username'],action='DELETE_ALL_SERVERS',details=f'Deleted all {count} servers and associated records'));db.commit();return RedirectResponse('/servers',303)
    finally:db.close()

@app.get('/servers/{server_id}',response_class=HTMLResponse)
def detail(request:Request,server_id:int):
    u=require_user(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        p=db.query(Patch).filter(Patch.server_id==server_id).order_by(Patch.patch_date.desc(),Patch.id.desc()).all(); cves=db.query(CVE).filter(CVE.server_id==server_id).order_by(CVE.status, CVE.severity.desc()).all(); jobs=db.query(AAPJob).filter(AAPJob.server_id==server_id).order_by(AAPJob.created_at.desc()).limit(10).all()
        return templates.TemplateResponse('server_detail.html',{'request':request,'user':u,'server':s,'patches':p,'latest':p[0] if p else None,'cves':cves,'aap_jobs':jobs,'aap_enabled':bool(AAP_URL and AAP_TOKEN and AAP_TEMPLATE_ID)})
    finally:db.close()

@app.post('/servers/{server_id}/patch')
def patch(request:Request,server_id:int,patch_date:str=Form(...),next_patch_date:str=Form(''),patch_type:str=Form('Monthly Patching'),os_version:str=Form(''),kernel_version:str=Form(''),performed_by:str=Form(''),source:str=Form('Manual'),result:str=Form('Success'),reboot_required:bool=Form(False),reboot_completed:bool=Form(False),aap_job_id:str=Form(''),comments:str=Form('')):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        p=Patch(server_id=server_id,patch_date=date.fromisoformat(patch_date),patch_type=clean(patch_type),os_version=clean(os_version),kernel_version=clean(kernel_version),performed_by=clean(performed_by),source=clean(source),result=clean(result) or 'Success',reboot_required=reboot_required,reboot_completed=reboot_completed,aap_job_id=clean(aap_job_id) or None,comments=clean(comments));db.add(p)
        if next_patch_date:s.next_patch_date=date.fromisoformat(next_patch_date)
        db.add(AuditLog(username=u['username'],action='ADD_PATCH',server_id=server_id,details=f'Patch recorded for {s.hostname}: {patch_date}, result={result}'));db.commit();return RedirectResponse(f'/servers/{server_id}',303)
    finally:db.close()

@app.post('/servers/{server_id}/cves')
def add_cve(request:Request,server_id:int,cve_id:str=Form(...),severity:str=Form('Medium'),package:str=Form(''),current_version:str=Form(''),fixed_version:str=Form(''),status:str=Form('Open'),detected_date:str=Form(''),remediated_date:str=Form(''),source:str=Form('Manual'),notes:str=Form('')):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        c=CVE(server_id=server_id,cve_id=clean(cve_id),severity=severity if severity in ('Critical','High','Medium','Low') else 'Medium',package=clean(package),current_version=clean(current_version),fixed_version=clean(fixed_version),status=status if status in ('Open','Remediated','Accepted Risk') else 'Open',detected_date=date.fromisoformat(detected_date) if detected_date else None,remediated_date=date.fromisoformat(remediated_date) if remediated_date else None,source=clean(source),notes=clean(notes));db.add(c);db.add(AuditLog(username=u['username'],action='ADD_CVE',server_id=server_id,details=f'Added {c.cve_id}'));db.commit();return RedirectResponse(f'/servers/{server_id}',303)
    finally:db.close()

@app.post('/cves/{cve_id}/remediate')
def remediate_cve(request:Request,cve_id:int):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        c=db.get(CVE,cve_id)
        if not c:raise HTTPException(404,'CVE not found')
        c.status='Remediated';c.remediated_date=date.today();db.add(AuditLog(username=u['username'],action='REMEDIATE_CVE',server_id=c.server_id,details=f'Remediated {c.cve_id}'));db.commit();return RedirectResponse(f'/servers/{c.server_id}',303)
    finally:db.close()

@app.post('/servers/{server_id}/patch-via-aap')
def patch_via_aap(request:Request,server_id:int):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    if not (AAP_URL and AAP_TOKEN and AAP_TEMPLATE_ID): raise HTTPException(503,'AAP integration is not configured')
    db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        payload={'extra_vars':{'portal_server_id':s.id,'hostname':s.hostname,'ip_address':s.ip_address,'instance_id':s.instance_id,'aws_account':s.aws_account,'environment':s.environment}}
        r=requests.post(f'{AAP_URL}/api/v2/job_templates/{AAP_TEMPLATE_ID}/launch/',headers={'Authorization':f'Bearer {AAP_TOKEN}','Content-Type':'application/json'},json=payload,verify=AAP_VERIFY_SSL,timeout=30)
        if r.status_code not in (200,201): raise HTTPException(502,f'AAP launch failed: HTTP {r.status_code}')
        data=r.json();job_id=str(data.get('job') or data.get('id') or '')
        if not job_id: raise HTTPException(502,'AAP did not return a job ID')
        db.add(AAPJob(server_id=s.id,job_id=job_id,status='Launched',launched_by=u['username']));db.add(AuditLog(username=u['username'],action='AAP_LAUNCH',server_id=s.id,details=f'Launched AAP job {job_id}'));db.commit();return RedirectResponse(f'/servers/{server_id}',303)
    finally:db.close()

@app.get('/users',response_class=HTMLResponse)
def users(request:Request):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:return templates.TemplateResponse('users.html',{'request':request,'user':u,'users':db.query(User).order_by(User.username).all()})
    finally:db.close()
@app.post('/users')
def create_user(request:Request,username:str=Form(...),password:str=Form(...),role:str=Form('readonly')):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    if len(clean(username))<3 or len(password)<8:raise HTTPException(400,'Username must be 3+ characters and password 8+ characters')
    db=SessionLocal()
    try:
        if db.query(User).filter_by(username=clean(username)).first():raise HTTPException(400,'Username already exists')
        role=role if role in ('readonly','admin') else 'readonly';db.add(User(username=clean(username),password_hash=pwd.hash(password),role=role));db.add(AuditLog(username=u['username'],action='CREATE_USER',details=f'Created {username} ({role})'));db.commit();return RedirectResponse('/users',303)
    finally:db.close()
@app.post('/users/{user_id}/delete')
def del_user(request:Request,user_id:int):
    u=require_admin(request)
    if isinstance(u,RedirectResponse):return u
    db=SessionLocal()
    try:
        x=db.get(User,user_id)
        if not x:raise HTTPException(404,'User not found')
        if x.id==u['id'] or x.username==ADMIN_USERNAME:raise HTTPException(400,'This user cannot be deleted')
        db.add(AuditLog(username=u['username'],action='DELETE_USER',details=f'Deleted user {x.username}'));db.delete(x);db.commit();return RedirectResponse('/users',303)
    finally:db.close()
@app.get('/profile/password',response_class=HTMLResponse)
def pw_page(request:Request):
    u=require_user(request);return u if isinstance(u,RedirectResponse) else templates.TemplateResponse('password.html',{'request':request,'user':u,'error':None,'success':None})
@app.post('/profile/password',response_class=HTMLResponse)
def pw_change(request:Request,current_password:str=Form(...),new_password:str=Form(...),confirm_password:str=Form(...)):
    u=require_user(request)
    if isinstance(u,RedirectResponse):return u
    if len(new_password)<8 or new_password!=confirm_password:return templates.TemplateResponse('password.html',{'request':request,'user':u,'error':'Passwords must match and be at least 8 characters.','success':None})
    db=SessionLocal()
    try:
        x=db.get(User,u['id'])
        if not x or not pwd.verify(current_password,x.password_hash):return templates.TemplateResponse('password.html',{'request':request,'user':u,'error':'Current password is incorrect.','success':None})
        x.password_hash=pwd.hash(new_password);db.add(AuditLog(username=u['username'],action='CHANGE_PASSWORD',details='User changed own password'));db.commit();return templates.TemplateResponse('password.html',{'request':request,'user':u,'error':None,'success':'Password changed successfully.'})
    finally:db.close()

@app.get('/import',response_class=HTMLResponse)
def import_page(request:Request):
    u=require_main_admin(request);return u if isinstance(u,RedirectResponse) else templates.TemplateResponse('import.html',{'request':request,'user':u,'result':None})
@app.post('/import',response_class=HTMLResponse)
async def import_csv(request:Request,csv_file:UploadFile=File(...)):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse):return u
    rows=csv.DictReader(io.StringIO((await csv_file.read()).decode('utf-8-sig')));db=SessionLocal();added=updated=skipped=0
    try:
        if not rows.fieldnames or not {'hostname','ip_address'}.issubset(rows.fieldnames):raise HTTPException(400,'CSV requires hostname and ip_address')
        for r in rows:
            h=clean(r.get('hostname'));ip=clean(r.get('ip_address'));iid=clean(r.get('instance_id'))
            if not h or not ip:skipped+=1;continue
            s=db.query(Server).filter(or_(Server.hostname==h,Server.ip_address==ip,Server.instance_id==iid if iid else Server.id==-1)).first()
            if not s:s=Server();added+=1
            else:updated+=1
            fields(s,h,ip,iid,r.get('os'),r.get('os_version'),r.get('environment'),r.get('application'),r.get('owner'),r.get('aws_account'),r.get('aws_account_id'),r.get('aws_region'),r.get('aws_group_tag'),r.get('next_patch_date'),r.get('status'));db.add(s)
        db.add(AuditLog(username=u['username'],action='IMPORT_CSV',details=f'added={added}, updated={updated}, skipped={skipped}'));db.commit();result=f'Import completed — Added: {added}, Updated: {updated}, Skipped: {skipped}';return templates.TemplateResponse('import.html',{'request':request,'user':u,'result':result})
    finally:db.close()

@app.get('/aws/accounts',response_class=HTMLResponse)
def aws_accounts(request:Request):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        accounts=db.query(AWSAccount).order_by(AWSAccount.name).all()
        counts={a.id:db.query(Server).filter(Server.aws_account_id==a.account_id).count() for a in accounts}
        return templates.TemplateResponse('aws_accounts.html',{'request':request,'user':u,'accounts':accounts,'counts':counts,'error':None,'success':None})
    finally: db.close()

@app.post('/aws/accounts')
def add_aws_account(request:Request,name:str=Form(...),account_id:str=Form(...),role_arn:str=Form(''),regions:str=Form(''),group_tag_key:str=Form('Group')):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        aid=clean(account_id); nm=clean(name); role=clean(role_arn) or None; regs=','.join([x.strip() for x in regions.split(',') if x.strip()]) or AWS_REGION
        if not aid.isdigit() or len(aid)!=12: raise HTTPException(400,'AWS Account ID must be 12 digits')
        if db.query(AWSAccount).filter_by(account_id=aid).first(): raise HTTPException(400,'AWS account already exists')
        a=AWSAccount(name=nm or aid,account_id=aid,role_arn=role,regions=regs,group_tag_key=clean(group_tag_key) or AWS_GROUP_TAG_KEY);db.add(a);db.add(AuditLog(username=u['username'],action='ADD_AWS_ACCOUNT',details=f'Added AWS account {aid}'));db.commit();return RedirectResponse('/aws/accounts',303)
    finally: db.close()

@app.post('/aws/accounts/{account_id}/test')
def test_aws_account(request:Request,account_id:int):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        a=db.get(AWSAccount,account_id)
        if not a: raise HTTPException(404,'AWS account configuration not found')
        session=aws_session_for(a); actual_id,actual_name=get_account_identity(session)
        if actual_id!=a.account_id: raise HTTPException(502,f'Role connected to account {actual_id}, expected {a.account_id}')
        a.sync_status='Connected'; a.sync_message=f'Connected as {actual_name} ({actual_id})'; db.commit();return RedirectResponse('/aws/accounts',303)
    except (BotoCoreError,ClientError) as e:
        db.rollback(); a=db.get(AWSAccount,account_id) if 'a' in locals() else None
        if a: a.sync_status='Failed';a.sync_message=str(e);db.commit()
        raise HTTPException(502,f'AWS connection failed: {e}')
    finally: db.close()

@app.post('/aws/accounts/{account_id}/sync')
def sync_one_aws_account(request:Request,account_id:int):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        a=db.get(AWSAccount,account_id)
        if not a: raise HTTPException(404,'AWS account configuration not found')
        seen,added,updated,patch_imported,patch_skipped=sync_aws_account(db,a);db.add(AuditLog(username=u['username'],action='AWS_ACCOUNT_SYNC',details=f'account={a.account_id}, seen={seen}, added={added}, updated={updated}'));db.commit();return RedirectResponse('/aws/accounts',303)
    except (BotoCoreError,ClientError) as e:
        db.rollback(); a=db.get(AWSAccount,account_id) if 'a' in locals() else None
        if a: a.sync_status='Failed';a.sync_message=str(e);db.commit()
        raise HTTPException(502,f'AWS sync failed: {e}')
    finally: db.close()

@app.post('/aws/accounts/sync-all')
def sync_all_aws_accounts(request:Request):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal();results=[]
    try:
        accounts=db.query(AWSAccount).filter(AWSAccount.enabled==True).all()
        for a in accounts:
            try:
                seen,added,updated,patch_imported,patch_skipped=sync_aws_account(db,a);results.append(f'{a.name}: {seen} seen, {added} added, {updated} updated')
                db.add(AuditLog(username=u['username'],action='AWS_ACCOUNT_SYNC',details=f'account={a.account_id}, seen={seen}, added={added}, updated={updated}'))
                db.commit()
            except Exception as e:
                db.rollback();a=db.get(AWSAccount,a.id);a.sync_status='Failed';a.sync_message=str(e);db.commit();results.append(f'{a.name}: FAILED - {e}')
        return RedirectResponse('/aws/accounts',303)
    finally: db.close()

@app.post('/aws/accounts/{account_id}/delete')
def delete_aws_account(request:Request,account_id:int):
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        a=db.get(AWSAccount,account_id)
        if not a: raise HTTPException(404,'AWS account configuration not found')
        # Do not delete server records; they retain their account ID/history.
        db.add(AuditLog(username=u['username'],action='DELETE_AWS_ACCOUNT',details=f'Removed AWS account config {a.account_id}; server records retained'));db.delete(a);db.commit();return RedirectResponse('/aws/accounts',303)
    finally: db.close()

@app.post('/aws/sync')
def aws_sync_legacy(request:Request):
    # Backward-compatible button: sync the local account using the EC2 instance role.
    u=require_main_admin(request)
    if isinstance(u,RedirectResponse): return u
    db=SessionLocal()
    try:
        a=db.query(AWSAccount).filter_by(account_id=boto3.client('sts').get_caller_identity()['Account']).first()
        if not a:
            aid,aname=get_account_identity(boto3.Session())
            a=AWSAccount(name=aname,account_id=aid,role_arn=None,regions=AWS_REGION,group_tag_key=AWS_GROUP_TAG_KEY);db.add(a);db.commit();db.refresh(a)
        sync_aws_account(db,a);db.add(AuditLog(username=u['username'],action='AWS_SYNC',details=f'local account={a.account_id}'));db.commit();return RedirectResponse('/servers',303)
    finally: db.close()

@app.get('/api/health')
def health():return {'status':'ok','version':'5.0'}
@app.get('/api/v1/servers/{server_id}')
def api_get(request:Request,server_id:int):
    api_authorized(request);db=SessionLocal()
    try:
        s=db.get(Server,server_id)
        if not s:raise HTTPException(404,'Server not found')
        latest=db.query(Patch).filter(Patch.server_id==server_id).order_by(Patch.patch_date.desc(),Patch.id.desc()).first();return {'id':s.id,'hostname':s.hostname,'ip_address':s.ip_address,'instance_id':s.instance_id,'os':s.os,'os_version':s.os_version,'environment':s.environment,'application':s.application,'owner':s.owner,'aws_account':s.aws_account,'aws_account_id':s.aws_account_id,'aws_region':s.aws_region,'aws_group_tag':s.aws_group_tag,'next_patch_date':s.next_patch_date.isoformat() if s.next_patch_date else None,'status':s.status,'latest_patch_date':latest.patch_date.isoformat() if latest else None}
    finally:db.close()
@app.post('/api/v1/servers/{server_id}/patch')
def api_patch(request:Request):
    api_authorized(request)
    # Read JSON manually because this endpoint is intended for AAP callbacks.
    import asyncio
    raise HTTPException(501,'Use /api/v1/patch-results for AAP callbacks')
@app.post('/api/v1/patch-results')
async def api_patch_result(request:Request):
    api_authorized(request); data=await request.json();db=SessionLocal()
    try:
        sid=data.get('server_id');s=db.get(Server,int(sid)) if sid else None
        if not s: raise HTTPException(404,'Server not found')
        p=Patch(server_id=s.id,patch_date=date.fromisoformat(data.get('patch_date',date.today().isoformat())),patch_type=clean(data.get('patch_type','Monthly Patching')),os_version=clean(data.get('os_version','')),kernel_version=clean(data.get('kernel_version','')),performed_by=clean(data.get('performed_by','AAP')),source=clean(data.get('source','AAP')),result=clean(data.get('result','Success')),reboot_required=bool(data.get('reboot_required',False)),reboot_completed=bool(data.get('reboot_completed',False)),aap_job_id=clean(str(data.get('aap_job_id',''))) or None,comments=clean(data.get('comments','')));db.add(p)
        if data.get('next_patch_date'):s.next_patch_date=date.fromisoformat(data['next_patch_date'])
        job_id=str(data.get('aap_job_id',''))
        if job_id:
            j=db.query(AAPJob).filter(AAPJob.job_id==job_id).first()
            if j:j.status=clean(data.get('result','Success'))
        db.add(AuditLog(username='API',action='API_PATCH_RESULT',server_id=s.id,details=f'AAP patch result for {s.hostname}: {p.result}'));db.commit();return {'status':'recorded','server_id':s.id,'patch_date':p.patch_date.isoformat(),'result':p.result}
    finally:db.close()
