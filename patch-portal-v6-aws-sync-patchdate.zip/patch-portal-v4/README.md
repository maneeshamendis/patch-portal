# Server Patch Portal V5 - Multi-Account AWS

This release extends the V4 portal with multi-account AWS EC2 inventory using IAM cross-account AssumeRole.

## AWS architecture

The portal EC2 instance uses its attached IAM role (for example `PatchPortalVMRole`). For each target AWS account, create `PatchPortalReadOnly` and trust the portal role. The portal then assumes the target role with STS and calls EC2 APIs using temporary credentials.

No long-lived AWS access keys are required in the application.

## Target role permissions

The target `PatchPortalReadOnly` role needs:

- `ec2:DescribeInstances`
- `ec2:DescribeTags`
- `ec2:DescribeRegions`
- `sts:GetCallerIdentity`
- `iam:ListAccountAliases`

## Portal account configuration

Main Admin -> AWS Accounts -> Add AWS Account.

For the portal VM's own account, leave Role ARN blank. For another account, enter for example:

`arn:aws:iam::822923364589:role/PatchPortalReadOnly`

Regions are comma-separated, for example:

`eu-west-1,eu-west-2`

Use Test before Sync.

## Upgrade

This release uses additive database migration and retains existing server/patch/CVE history. Back up PostgreSQL before upgrading. Do not use `docker compose down -v` during an upgrade.
