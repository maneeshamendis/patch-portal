# Patch Portal V22.0

V22.0 keeps the V21.2 Cost Control start-confirmation behaviour and updates only the Cost Control reporting layer.

## Savings reporting

The portal separates two concepts:

- **Gross On-Demand Equivalent Avoidance** — portal-owned stopped hours multiplied by the configured Cost Rate. This is a reference value, not an AWS invoice saving.
- **AWS Savings Plans metrics** — last complete calendar month, read from AWS Cost Explorer for AWS accounts represented by enabled Power Groups. The report shows coverage, utilization, unused commitment, AWS Savings Plan net savings and the On-Demand equivalent.

Savings Plan metrics are account-level. They are not attributed to individual servers because Savings Plans are applied to eligible usage at the AWS account/organization level.

## IAM

Add the `ReadSavingsPlanMetrics` statement from `cost-control-iam-policy.json` to the IAM role assumed by Patch Portal in each AWS account whose Cost Control Power Groups should display Savings Plan metrics.

The EC2 start/stop permissions are unchanged.

If Cost Explorer permissions are not present, the Cost Control report continues to work and explicitly shows the AWS Savings Plan section as unavailable instead of inventing a savings figure.

## Deployment

The ZIP is direct-extract compatible with the existing `/opt/patch-portal/patch-portal-v6` deployment process. It does not contain a nested `patch-portal-v6/` directory.
