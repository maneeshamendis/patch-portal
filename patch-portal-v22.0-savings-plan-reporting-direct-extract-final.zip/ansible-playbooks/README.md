# Patch Portal V20 validation playbooks

Recommended Patch Group mapping:

RHEL
- precheck-rhel.yaml
- your RHEL patch playbook (for example yum-update-rhel.yaml)
- reboot-linux.yaml
- postcheck-rhel.yaml

Amazon Linux
- precheck-amazon-linux.yaml
- your Amazon Linux patch playbook
- reboot-linux.yaml
- postcheck-amazon-linux.yaml

Windows
- precheck-windows.yaml
- your Windows patch playbook
- reboot-windows.yaml
- postcheck-windows.yaml

Safety behavior:
- Pre-validation failures are hard gates. The portal will not create the AMI or start patching for that server.
- Patch failures stop the server's automation.
- Reboot failures leave the successful patch history/AMI intact and mark the automation job failed.
- Post-validation failures mark the automation job failed while preserving the successful patch history and AMI for investigation/recovery.
- A Patch Group can be configured to continue remaining servers or stop remaining queued servers after a failure.

Customize required_services in the pre/post playbook per Patch Group/application. Keep application-specific checks (HTTP health endpoint, application port, database connectivity, cluster membership, etc.) in dedicated playbooks where required.

Windows execution through the portal requires a Windows-capable Ansible connection configuration already supported by the environment (commonly WinRM/PSRP). The included Windows reboot/validation playbooks use ansible.windows.
