## Patch Portal V21.2

Cost Control START confirmation fix.

- Uses the EC2 Instance ID already stored in the portal.
- `stopped`: calls StartInstances and waits until EC2 reports `running`.
- `pending`: waits until EC2 reports `running` instead of treating it as already running.
- Ownership is released only after a confirmed successful start (or when the instance is already running as a manual override).
- Start timeout/failure leaves Cost Control stop ownership active for retry.
- Direct-extract package; no nested `patch-portal-v6/` directory.
