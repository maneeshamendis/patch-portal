import os, time, subprocess, traceback, tempfile, shutil, stat, base64, hashlib
from datetime import datetime, date
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy import create_engine, String, Integer, Date, DateTime, ForeignKey, Text, Boolean
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

DB=os.environ['DATABASE_URL']
ROOT=Path(os.environ.get('GIT_REPO_ROOT','/data/git-repos'))
SECRET_KEY=os.environ['SECRET_KEY']
HOST_KEY_CHECKING=os.environ.get('ANSIBLE_HOST_KEY_CHECKING','false').lower() == 'true'

engine=create_engine(DB,pool_pre_ping=True)
Session=sessionmaker(bind=engine,autoflush=False)

class Base(DeclarativeBase): pass

class AnsibleJob(Base):
    __tablename__='ansible_jobs'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    job_type:Mapped[str]=mapped_column(String(50),default='syntax_check')
    playbook_id:Mapped[int|None]=mapped_column(Integer,nullable=True)
    server_id:Mapped[int|None]=mapped_column(Integer,nullable=True)
    status:Mapped[str]=mapped_column(String(30),default='Queued')
    requested_by:Mapped[str]=mapped_column(String(100))
    logs:Mapped[str|None]=mapped_column(Text,nullable=True)
    exit_code:Mapped[int|None]=mapped_column(Integer,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    started_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
    finished_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)

class Playbook(Base):
    __tablename__='ansible_playbooks'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    repository_id:Mapped[int]=mapped_column(Integer)
    name:Mapped[str]=mapped_column(String(255))
    path:Mapped[str]=mapped_column(String(1000))
    last_commit:Mapped[str|None]=mapped_column(String(100),nullable=True)
    last_synced:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)

class Server(Base):
    __tablename__='servers'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    hostname:Mapped[str]=mapped_column(String(255))
    ip_address:Mapped[str]=mapped_column(String(64))
    instance_id:Mapped[str|None]=mapped_column(String(100),nullable=True)
    os:Mapped[str|None]=mapped_column(String(100),nullable=True)
    os_version:Mapped[str|None]=mapped_column(String(100),nullable=True)
    environment:Mapped[str|None]=mapped_column(String(100),nullable=True)
    application:Mapped[str|None]=mapped_column(String(255),nullable=True)
    owner:Mapped[str|None]=mapped_column(String(255),nullable=True)
    aws_account:Mapped[str|None]=mapped_column(String(255),nullable=True)
    aws_account_id:Mapped[str|None]=mapped_column(String(30),nullable=True)
    aws_region:Mapped[str|None]=mapped_column(String(50),nullable=True)
    aws_group_tag:Mapped[str|None]=mapped_column(String(255),nullable=True)
    ssh_credential_id:Mapped[int|None]=mapped_column(Integer,nullable=True)
    next_patch_date:Mapped[date|None]=mapped_column(Date,nullable=True)
    status:Mapped[str]=mapped_column(String(30),default='Running')

class SSHCredential(Base):
    __tablename__='ssh_credentials'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    name:Mapped[str]=mapped_column(String(255))
    username:Mapped[str]=mapped_column(String(100))
    private_key_encrypted:Mapped[str]=mapped_column(Text)
    passphrase_encrypted:Mapped[str|None]=mapped_column(Text,nullable=True)
    patch_group:Mapped[str|None]=mapped_column(String(255),nullable=True)
    enabled:Mapped[bool]=mapped_column(Boolean,default=True)

class Patch(Base):
    __tablename__='patches'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    server_id:Mapped[int]=mapped_column(Integer)
    patch_date:Mapped[date]=mapped_column(Date)
    patch_type:Mapped[str|None]=mapped_column(String(100),nullable=True)
    os_version:Mapped[str|None]=mapped_column(String(100),nullable=True)
    kernel_version:Mapped[str|None]=mapped_column(String(255),nullable=True)
    performed_by:Mapped[str|None]=mapped_column(String(255),nullable=True)
    source:Mapped[str|None]=mapped_column(String(50),nullable=True)
    result:Mapped[str|None]=mapped_column(String(50),default='Success')
    reboot_required:Mapped[bool]=mapped_column(Boolean,default=False)
    reboot_completed:Mapped[bool]=mapped_column(Boolean,default=False)
    aap_job_id:Mapped[str|None]=mapped_column(String(100),nullable=True)
    comments:Mapped[str|None]=mapped_column(Text,nullable=True)

class AMIBackup(Base):
    __tablename__='ami_backups'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    server_id:Mapped[int]=mapped_column(Integer)
    ami_id:Mapped[str|None]=mapped_column(String(100),nullable=True)
    ami_name:Mapped[str|None]=mapped_column(String(255),nullable=True)
    status:Mapped[str]=mapped_column(String(30),default='Creating')
    region:Mapped[str|None]=mapped_column(String(50),nullable=True)
    aws_account_id:Mapped[str|None]=mapped_column(String(30),nullable=True)
    no_reboot:Mapped[bool]=mapped_column(Boolean,default=True)
    requested_by:Mapped[str]=mapped_column(String(100))
    error_message:Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    completed_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)

def encryption_key():
    return base64.urlsafe_b64encode(hashlib.sha256(SECRET_KEY.encode()).digest())

fernet=Fernet(encryption_key())

def decrypt_secret(value):
    if not value:
        return ''
    try:
        return fernet.decrypt(value.encode()).decode()
    except InvalidToken:
        raise RuntimeError('Stored SSH credential cannot be decrypted. Check SECRET_KEY.')

def set_log(db,job,text):
    job.logs=(job.logs or '') + text
    job.logs=job.logs[-100000:]
    db.commit()

def effective_credential(db, server):
    c=None
    if server.ssh_credential_id:
        c=db.get(SSHCredential,server.ssh_credential_id)
        if c and c.enabled:
            return c
    if server.aws_group_tag:
        for candidate in db.query(SSHCredential).filter(SSHCredential.enabled==True).order_by(SSHCredential.id.asc()).all():
            if candidate.patch_group and candidate.patch_group.lower()==server.aws_group_tag.lower():
                return candidate
    return None

def run_patch(job_id):
    db=Session()
    job=db.get(AnsibleJob,job_id)
    server=db.get(Server,job.server_id) if job.server_id else None
    play=db.get(Playbook,job.playbook_id) if job.playbook_id else None
    tempdir=None
    agent_proc=None
    try:
        job.status='Running'
        job.started_at=datetime.utcnow()
        job.logs='Ansible patch job started.\n'
        db.commit()

        if not server: raise RuntimeError('Server not found.')
        if not play: raise RuntimeError('Playbook not found.')
        if server.status == 'Terminated': raise RuntimeError('Server is Terminated.')
        cred=effective_credential(db,server)
        if not cred: raise RuntimeError('No enabled SSH credential is mapped to this server or its PatchGroup.')

        repo=ROOT/str(play.repository_id)
        play_path=(repo/play.path).resolve()
        repo_path=repo.resolve()
        if not play_path.exists(): raise RuntimeError(f'Playbook file not found: {play_path}')
        if repo_path not in play_path.parents: raise RuntimeError('Invalid playbook path.')

        key=decrypt_secret(cred.private_key_encrypted)
        passphrase=decrypt_secret(cred.passphrase_encrypted) if cred.passphrase_encrypted else ''
        tempdir=Path(tempfile.mkdtemp(prefix=f'patchportal-job-{job.id}-'))
        key_path=tempdir/'id_key'
        key_path.write_text(key)
        os.chmod(key_path,0o600)

        inventory=tempdir/'inventory.ini'
        inventory.write_text(
            '[patch_target]\n'
            f'{server.hostname} ansible_host={server.ip_address} ansible_user={cred.username} '
            'ansible_python_interpreter=auto_silent\n'
        )
        os.chmod(inventory,0o600)

        env=os.environ.copy()
        env['ANSIBLE_HOST_KEY_CHECKING']='True' if HOST_KEY_CHECKING else 'False'
        env['ANSIBLE_NOCOLOR']='1'
        env['ANSIBLE_RETRY_FILES_ENABLED']='False'
        env['ANSIBLE_LOCALHOST_WARNING']='False'

        # If the key is passphrase-protected, load it into a temporary ssh-agent.
        if passphrase:
            agent=subprocess.run(['ssh-agent','-s'],capture_output=True,text=True,check=True)
            for line in agent.stdout.splitlines():
                if line.startswith('SSH_AUTH_SOCK='):
                    env['SSH_AUTH_SOCK']=line.split(';',1)[0].split('=',1)[1]
                elif line.startswith('SSH_AGENT_PID='):
                    env['SSH_AGENT_PID']=line.split(';',1)[0].split('=',1)[1]
            askpass=tempdir/'askpass.sh'
            askpass.write_text('#!/bin/sh\nprintf "%s\\n" "$SSH_KEY_PASSPHRASE"\n')
            os.chmod(askpass,0o700)
            env['SSH_ASKPASS']=str(askpass)
            env['SSH_KEY_PASSPHRASE']=passphrase
            env['DISPLAY']='patchportal:0'
            subprocess.run(['ssh-add',str(key_path)],env=env,check=True,capture_output=True,text=True)

        set_log(db,job,f'Server: {server.hostname} ({server.ip_address})\n')
        set_log(db,job,f'Playbook: {play.name} ({play.path})\n')
        set_log(db,job,f'SSH credential: {cred.name} / {cred.username}\n')
        set_log(db,job,'Starting ansible-playbook...\n\n')

        proc=subprocess.Popen(
            ['ansible-playbook','-i',str(inventory),str(play_path),'--private-key',str(key_path)],
            cwd=str(repo),
            stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,env=env
        )
        for line in proc.stdout:
            # Never expose credential material.
            safe=line.replace(passphrase,'[REDACTED]') if passphrase else line
            set_log(db,job,safe)
        rc=proc.wait()
        job.exit_code=rc
        job.finished_at=datetime.utcnow()
        job.status='Success' if rc==0 else 'Failed'
        db.commit()

        if rc==0:
            patch=Patch(
                server_id=server.id,
                patch_date=date.today(),
                patch_type='Ansible Patching',
                os_version=server.os_version,
                performed_by=job.requested_by,
                source='Ansible',
                result='Success',
                reboot_required=False,
                reboot_completed=False,
                aap_job_id=f'ANSIBLE-{job.id}',
                comments=f'Playbook: {play.name}; Git commit: {play.last_commit or "-"}; Ansible Job #{job.id}'
            )
            db.add(patch)
            db.commit()
            set_log(db,job,'\nPATCH RESULT: SUCCESS\nPatch history record created automatically.\n')
        else:
            set_log(db,job,'\nPATCH RESULT: FAILED\nNo successful patch history record was created.\n')
    except Exception as e:
        job.status='Failed'
        job.exit_code=1
        job.finished_at=datetime.utcnow()
        job.logs=(job.logs or '') + '\nERROR: '+str(e)+'\n'+traceback.format_exc()
        job.logs=job.logs[-100000:]
        db.commit()
    finally:
        try:
            if env.get('SSH_AGENT_PID') and env.get('SSH_AUTH_SOCK'):
                subprocess.run(['ssh-agent','-k'],env=env,capture_output=True,text=True)
        except Exception:
            pass
        if tempdir:
            shutil.rmtree(tempdir,ignore_errors=True)
        db.close()

def run_syntax(job_id):
    db=Session(); job=db.get(AnsibleJob,job_id); p=db.get(Playbook,job.playbook_id) if job.playbook_id else None
    try:
        job.status='Running'; job.started_at=datetime.utcnow(); job.logs='Worker started.\n'; db.commit()
        if not p: raise RuntimeError('Playbook not found.')
        repo=ROOT/str(p.repository_id); play=repo/p.path
        if not play.exists(): raise RuntimeError(f'Playbook file not found: {play}')
        proc=subprocess.Popen(['ansible-playbook','--syntax-check',str(play)],cwd=str(repo),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
        lines=[]
        for line in proc.stdout:
            lines.append(line); job.logs=''.join(lines)[-50000:]; db.commit()
        rc=proc.wait(); job.exit_code=rc; job.finished_at=datetime.utcnow(); job.status='Success' if rc==0 else 'Failed'; db.commit()
    except Exception as e:
        job.logs=(job.logs or '')+'ERROR: '+str(e)+'\n'+traceback.format_exc(); job.exit_code=1; job.finished_at=datetime.utcnow(); job.status='Failed'; db.commit()
    finally: db.close()

def run(job_id):
    db=Session()
    job=db.get(AnsibleJob,job_id)
    if not job:
        db.close()
        print(f'Job {job_id} no longer exists',flush=True)
        return
    job_type=job.job_type
    db.close()
    # Each runner loads its own fresh ORM object/session.
    if job_type=='patch':
        run_patch(job_id)
    elif job_type=='syntax_check':
        run_syntax(job_id)
    else:
        db=Session()
        job=db.get(AnsibleJob,job_id)
        job.status='Failed'
        job.exit_code=1
        job.finished_at=datetime.utcnow()
        job.logs=(job.logs or '')+f'Unsupported job type: {job_type}\n'
        db.commit()
        db.close()

def main():
    print('Ansible worker started',flush=True)
    while True:
        db=Session()
        job=db.query(AnsibleJob).filter(AnsibleJob.status=='Queued').order_by(AnsibleJob.id).first()
        if job:
            job_id=job.id
            db.commit()
            db.close()
            run(job_id)
        else:
            db.close(); time.sleep(2)

if __name__=='__main__': main()
