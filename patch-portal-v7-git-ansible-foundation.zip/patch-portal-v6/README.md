# Server Patch Portal V7

V7 adds private Git repository management and Ansible playbook discovery.

## V7 features
- Main-admin-only Ansible page
- HTTPS Git repository configuration
- GitHub Personal Access Token (PAT) support
- PAT encrypted at rest using a key derived from `SECRET_KEY`
- PAT is never written into Git URLs or command-line arguments
- Repository connectivity test
- Branch selection
- Clone/fetch/reset synchronization
- YAML playbook discovery (`.yml` / `.yaml`)
- Persistent local Git repository volume

## GitHub PAT
Use a fine-grained PAT restricted to the required private repository with `Contents: Read-only`.

## V7 does not execute Ansible yet
Ansible execution, encrypted SSH keys, AMI backup and patching workflows are planned for later versions.

## Deployment
Preserve the existing PostgreSQL volume and `.env`. Do not use `docker compose down -v`.
