import os, time, subprocess, traceback
from datetime import datetime
from pathlib import Path
from sqlalchemy import create_engine, String, Integer, Date, DateTime, ForeignKey, Text, Boolean
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

DB=os.environ['DATABASE_URL']; ROOT=Path(os.environ.get('GIT_REPO_ROOT','/data/git-repos'))
engine=create_engine(DB,pool_pre_ping=True); Session=sessionmaker(bind=engine,autoflush=False)
class Base(DeclarativeBase): pass
class AnsibleJob(Base):
    __tablename__='ansible_jobs'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    job_type:Mapped[str]=mapped_column(String(50),default='syntax_check')
    playbook_id:Mapped[int|None]=mapped_column(Integer,nullable=True)
    server_id:Mapped[int|None]=mapped_column(Integer,nullable=True)
    status:Mapped[str]=mapped_column(String(30),default='Queued')
    requested_by:Mapped[str]=mapped_column(String(100))
    logs:Mapped[str|None]=mapped_column(Text,nullable=True)
    exit_code:Mapped[int|None]=mapped_column(Integer,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    started_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
    finished_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
class Playbook(Base):
    __tablename__='ansible_playbooks'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    repository_id:Mapped[int]=mapped_column(Integer)
    name:Mapped[str]=mapped_column(String(255))
    path:Mapped[str]=mapped_column(String(1000))
    last_commit:Mapped[str|None]=mapped_column(String(100),nullable=True)
    last_synced:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)

def run(job):
    db=Session(); job=db.get(AnsibleJob,job.id); p=db.get(Playbook,job.playbook_id) if job.playbook_id else None
    job.status='Running'; job.started_at=datetime.utcnow(); job.logs='Worker started.\n'; db.commit()
    try:
        if job.job_type!='syntax_check': raise RuntimeError('Unsupported job type in V8 worker.')
        if not p: raise RuntimeError('Playbook not found.')
        repo=ROOT/str(p.repository_id); play=repo/p.path
        if not play.exists(): raise RuntimeError(f'Playbook file not found: {play}')
        proc=subprocess.Popen(['ansible-playbook','--syntax-check',str(play)],cwd=str(repo),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
        lines=[]
        for line in proc.stdout:
            lines.append(line); job.logs=''.join(lines)[-50000:]; db.commit()
        rc=proc.wait(); job.exit_code=rc; job.finished_at=datetime.utcnow(); job.status='Success' if rc==0 else 'Failed'; db.commit()
    except Exception as e:
        job.logs=(job.logs or '')+'ERROR: '+str(e)+'\n'+traceback.format_exc(); job.exit_code=1; job.finished_at=datetime.utcnow(); job.status='Failed'; db.commit()
    finally: db.close()

def main():
    print('Ansible worker started',flush=True)
    while True:
        db=Session(); job=db.query(AnsibleJob).filter(AnsibleJob.status=='Queued').order_by(AnsibleJob.id).first();
        if job:
            job.status='Claimed'; db.commit(); db.close(); run(job)
        else:
            db.close(); time.sleep(2)
if __name__=='__main__': main()
