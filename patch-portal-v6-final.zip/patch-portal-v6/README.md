# Server Patch Portal V6 — Multi-Account AWS

## V6 features
- AWS Accounts management for main_admin
- Cross-account IAM AssumeRole
- Sync AWS Accounts button on Servers page
- AWS Group Tag column and search
- EC2 PatchDate tag imported into patch history
- Multi-account + multi-region inventory
- Running/Stopped/Terminated status sync
- Existing patch/CVE/AAP/API features retained

## Upgrade
1. Back up PostgreSQL.
2. Do NOT use `docker compose down -v`.
3. Extract this directory as `patch-portal-v6`.
4. Copy your existing `.env` into the new directory.
5. Ensure the VM uses its EC2 IAM role; do not put AWS access keys in `.env`.
6. `docker compose build --no-cache`
7. `docker compose up -d`
8. Verify with `docker compose ps` — container names should start with `patch-portal-v6-`.

For cross-account inventory, configure an AWS Account in the portal with the target account ID, `arn:aws:iam::<ACCOUNT_ID>:role/PatchPortalReadOnly`, and regions.
