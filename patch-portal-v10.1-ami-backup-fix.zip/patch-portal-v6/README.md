# Server Patch Portal V8

V8 adds an Ansible worker and persistent job queue on top of V7 Git repository/playbook discovery.

## V8 features
- Private Git repositories with encrypted PATs
- Playbook discovery
- Ansible worker container
- Persistent Ansible job queue in PostgreSQL
- Playbook syntax validation jobs
- Live-ish job output page with auto-refresh
- Audit entry when validation is queued

## Not yet enabled
Remote server execution requires the V9 SSH credential layer. Do not put private keys in Git or the database as plaintext.

## Deployment
Preserve the existing PostgreSQL volume. Do not use `docker compose down -v`.


## V9 SSH credentials

- Main Admin can add encrypted SSH private keys.
- Keys are encrypted at rest using the portal SECRET_KEY-derived Fernet key.
- Private keys are never displayed or downloadable.
- Credentials can be associated with a PatchGroup or explicitly mapped to a server.
- Server-level mapping takes precedence over PatchGroup inheritance.
- Remote execution is intentionally not enabled in V9; V10 will use these credentials for controlled Ansible/AWS operations.

## V10 AMI backup

The server page has a **Back Up** button for Main Admin/Admin users. It creates an EC2 AMI using `NoReboot=True`, records the AMI in the portal, polls until `available`, and applies the requested tag:
`Name=<ServerName>-AMI-Patching-Portal`.

Required permissions for the portal EC2 role / target cross-account role include:
- `ec2:CreateImage`
- `ec2:DescribeImages`
- `ec2:CreateTags` (for the AMI tag)
- `ec2:DescribeInstances` (already used by inventory sync)

For cross-account backups, the portal's source IAM role must be allowed to `sts:AssumeRole` into the target account's `PatchPortalReadOnly`/backup-capable role. If the existing target role is strictly read-only and does not permit AMI creation, create a dedicated patch portal operations role (recommended) with the minimum EC2 backup permissions above.

## V10.1 AMI backup fix

The **Back Up** action is independent of patch history. Users can create an AMI without first saving a patch record. The backup is tracked separately and the next patching stage can require a successful backup before allowing patch execution.

Required target-account permissions:
- `ec2:CreateImage`
- `ec2:DescribeImages`
- `ec2:DescribeInstances`
- `ec2:CreateTags`
