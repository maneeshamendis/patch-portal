# Server Patch Portal V8

V8 adds an Ansible worker and persistent job queue on top of V7 Git repository/playbook discovery.

## V8 features
- Private Git repositories with encrypted PATs
- Playbook discovery
- Ansible worker container
- Persistent Ansible job queue in PostgreSQL
- Playbook syntax validation jobs
- Live-ish job output page with auto-refresh
- Audit entry when validation is queued

## Not yet enabled
Remote server execution requires the V9 SSH credential layer. Do not put private keys in Git or the database as plaintext.

## Deployment
Preserve the existing PostgreSQL volume. Do not use `docker compose down -v`.


## V9 SSH credentials

- Main Admin can add encrypted SSH private keys.
- Keys are encrypted at rest using the portal SECRET_KEY-derived Fernet key.
- Private keys are never displayed or downloadable.
- Credentials can be associated with a PatchGroup or explicitly mapped to a server.
- Server-level mapping takes precedence over PatchGroup inheritance.
- Remote execution is intentionally not enabled in V9; V10 will use these credentials for controlled Ansible/AWS operations.

## V10 AMI backup

The server page has a **Back Up** button for Main Admin/Admin users. It creates an EC2 AMI using `NoReboot=True`, records the AMI in the portal, polls until `available`, and applies the requested tag:
`Name=<ServerName>-AMI-Patching-Portal`.

Required permissions for the portal EC2 role / target cross-account role include:
- `ec2:CreateImage`
- `ec2:DescribeImages`
- `ec2:CreateTags` (for the AMI tag)
- `ec2:DescribeInstances` (already used by inventory sync)

For cross-account backups, the portal's source IAM role must be allowed to `sts:AssumeRole` into the target account's `PatchPortalReadOnly`/backup-capable role. If the existing target role is strictly read-only and does not permit AMI creation, create a dedicated patch portal operations role (recommended) with the minimum EC2 backup permissions above.

## V10.1 AMI backup fix

The **Back Up** action is independent of patch history. Users can create an AMI without first saving a patch record. The backup is tracked separately and the next patching stage can require a successful backup before allowing patch execution.

Required target-account permissions:
- `ec2:CreateImage`
- `ec2:DescribeImages`
- `ec2:DescribeInstances`
- `ec2:CreateTags`

## V10.2 fix

Fixes the AMI backup endpoint authorization helper (`require_role`) so Main Admin and Admin users can execute independent AMI backups.

## V11 Ansible patch execution

- **Patch Server** is available to Main Admin/Admin users.
- User selects an approved playbook discovered from Git.
- The server's explicit SSH credential is used, otherwise its PatchGroup mapping is used.
- A successful `Available` No-Reboot AMI backup is required before the job can be queued.
- The worker executes `ansible-playbook` against a generated one-host inventory.
- Execution output is stored in the Ansible job.
- On successful execution, the portal automatically creates a Patch History record with source `Ansible`.
- Private keys are decrypted only inside the worker's temporary job directory and are removed after execution.

## V11.1 worker fix

Fixes SQLAlchemy `DetachedInstanceError` in the Ansible worker by passing the job ID between worker sessions and reloading the job in a fresh session before execution.

## V11.2 SSH key validation

The Ansible worker now normalizes decrypted SSH private keys (BOM/CRLF/literal newline handling), validates them with `ssh-keygen`, and performs an SSH pre-flight connection before launching Ansible. If either validation fails, the job fails with a clear reason and the playbook is not executed.

## V11.3 patch/reboot tracking

After a successful Ansible patch:
- A Patch History record is created automatically.
- The portal detects an explicit reboot-required message in Ansible output.
- `reboot_required` is stored on the patch record.
- The EC2 instance gets `PatchDate=YYYY-MM-DD`; existing PatchDate is overwritten.
- If reboot is required, an independent **Reboot Server** button appears.
- Reboot is executed by a controlled Ansible `ansible.builtin.reboot` workflow and verifies post-reboot connectivity.
- On successful reboot, the patch record is marked `reboot_completed=True`.

## V11.4
Worker-side schema bootstrap, safe rollback handling, reboot-required detection, independent reboot workflow, and automatic PatchDate tagging.

## V11.5 patch completion fix

- Adds the missing `update_patch_date_tag()` implementation that V11.4 referenced.
- Adds the AWS account/role model and STS AssumeRole logic to the worker.
- Successful Ansible patch execution now creates Patch History and updates the EC2 `PatchDate` tag.
- AWS tag failures are reported as warnings without losing the successful Patch History record.
- Worker bootstraps its required tables at startup.

## V11.6 release identification

Application and Ansible worker images are tagged with the portal release:
- `patch-portal-v6-app:11.6`
- `patch-portal-v6-ansible-worker:11.6`

Check with:
`docker ps --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}'`

The application also exposes `/version`.

## V11.7 reboot workflow

Reboot Server uses the same administrator permission as patching. It automatically selects an approved Git playbook whose name/path contains `restart` or `reboot` (for example `restart-servers.yaml`). The job inventory contains only the selected server. If no matching Git playbook exists, it falls back to the built-in `ansible.builtin.reboot` workflow. Successful completion marks the latest patch as reboot completed.

## V11.8 reboot UI fix

- Reboot pending detection no longer depends on `result == 'Success'`.
- Reboot action is calculated explicitly from the logged-in user's role.
- A prominent Reboot Required card is shown on the server page for admin/main_admin users.
- Server information includes a Reboot Required status.
- Release version is 11.8.

## V11.9 critical patch-history fix

The Ansible worker previously mapped its `Patch` ORM model to `patches`, while the portal stores patch history in `patch_history`. This caused the worker to report a successful post-processing message without creating a record visible to the portal.

V11.9 maps the worker to `patch_history`, verifies that table at worker startup, and prints the release/build identifier.

## V12.0 patch history timestamp fix

The worker now maps `Patch.created_at` to the existing non-null `patch_history.created_at` column and explicitly supplies `created_at=datetime.utcnow()` when creating an Ansible patch history record. Startup validates that `patch_history.created_at` exists.

## V12.1 reboot SSH key fix

The reboot worker now uses the same private-key normalization as the working patch worker. It writes a real newline at the end of the key rather than a literal `\\n`, and supports encrypted private keys via a temporary ssh-agent.
